DP Trojan by Fire-Crow
-----------------------
Put the DLL file in the Windows System Folder
1.)Put the Viagra.exe file in the victim computer and Double Click on him - this action will install the server in
victim's system, what you realy see when you do this is: your pointer grow up that's it !

2.)Got to your computer and Double Click on the DP Trojan.exe file - this is the clinet, there input the victim IP
and press on the connect button, then you are in !

Have Fun !

If you want to contect me :

ICQ : 40001831
Mirc : irc.dal.net , room: #����� or #DPTrojan
E-Mail : p_doron@hotmail.com

See Ya !