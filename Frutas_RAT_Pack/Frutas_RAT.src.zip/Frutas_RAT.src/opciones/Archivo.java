/*    */ package opciones;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class Archivo
/*    */   implements Serializable
/*    */ {
/*    */   private String path;
/*    */   private String pathParent;
/*    */   private String nombre;
/*    */   private long length;
/*    */   private boolean carpeta;
/*    */   private long fecha;
/*    */   private boolean hidden;
/*    */ 
/*    */   public String getPath()
/*    */   {
/* 15 */     return this.path;
/*    */   }
/*    */ 
/*    */   public void setPath(String path) {
/* 19 */     this.path = path;
/*    */   }
/*    */ 
/*    */   public String getPathParent() {
/* 23 */     return this.pathParent;
/*    */   }
/*    */ 
/*    */   public void setPathParent(String pathParent) {
/* 27 */     this.pathParent = pathParent;
/*    */   }
/*    */ 
/*    */   public String getNombre() {
/* 31 */     return this.nombre;
/*    */   }
/*    */ 
/*    */   public void setNombre(String nombre) {
/* 35 */     this.nombre = nombre;
/*    */   }
/*    */ 
/*    */   public long getLength() {
/* 39 */     return this.length;
/*    */   }
/*    */ 
/*    */   public void setLength(long length) {
/* 43 */     this.length = length;
/*    */   }
/*    */ 
/*    */   public boolean isCarpeta() {
/* 47 */     return this.carpeta;
/*    */   }
/*    */ 
/*    */   public void setCarpeta(boolean carpeta) {
/* 51 */     this.carpeta = carpeta;
/*    */   }
/*    */ 
/*    */   public long getFecha() {
/* 55 */     return this.fecha;
/*    */   }
/*    */ 
/*    */   public void setFecha(long fecha) {
/* 59 */     this.fecha = fecha;
/*    */   }
/*    */ 
/*    */   public boolean isHidden() {
/* 63 */     return this.hidden;
/*    */   }
/*    */ 
/*    */   public void setHidden(boolean hidden) {
/* 67 */     this.hidden = hidden;
/*    */   }
/*    */ 
/*    */   public Archivo() {
/*    */   }
/*    */ 
/*    */   public Archivo(String path, String pathParent, String nombre, long length, boolean carpeta, long fecha, boolean hidden) {
/* 74 */     this.path = path;
/* 75 */     this.pathParent = pathParent;
/* 76 */     this.nombre = nombre;
/* 77 */     this.length = length;
/* 78 */     this.carpeta = carpeta;
/* 79 */     this.fecha = fecha;
/* 80 */     this.hidden = hidden;
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     opciones.Archivo
 * JD-Core Version:    0.6.2
 */