/*    */ import java.awt.AWTException;
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.Rectangle;
/*    */ import java.awt.Robot;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.image.BufferedImage;
/*    */ import java.io.IOException;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ import javax.swing.JPanel;
/*    */ 
/*    */ public class Ima
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws IOException, InterruptedException, AWTException
/*    */   {
/* 25 */     Robot ro = new Robot();
/*    */ 
/* 27 */     BufferedImage image = ro.createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
/*    */ 
/* 32 */     Image im = image.getScaledInstance((int)(image.getWidth() / 0.5D), (int)(image.getHeight() / 0.5D), 1);
/* 33 */     ImageIcon m = new ImageIcon(im);
/* 34 */     BufferedImage mm = new BufferedImage(im.getWidth(null), im.getHeight(null), 11);
/* 35 */     mm.getGraphics().drawImage(im, 0, 0, im.getWidth(null), im.getHeight(null), null);
/*    */ 
/* 38 */     Image tm = mm.getScaledInstance(mm.getWidth() / 2, mm.getHeight() / 2, 1);
/*    */ 
/* 40 */     JFrame f = new JFrame();
/* 41 */     f.setDefaultCloseOperation(3);
/* 42 */     JPanel panel = new JPanel();
/* 43 */     JLabel la = new JLabel();
/* 44 */     la.setIcon(m);
/*    */ 
/* 46 */     JLabel l = new JLabel();
/* 47 */     l.setIcon(new ImageIcon(tm));
/*    */ 
/* 49 */     panel.add(l);
/* 50 */     panel.add(la);
/* 51 */     f.add(panel);
/*    */ 
/* 53 */     f.setVisible(true);
/* 54 */     f.pack();
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     Ima
 * JD-Core Version:    0.6.2
 */