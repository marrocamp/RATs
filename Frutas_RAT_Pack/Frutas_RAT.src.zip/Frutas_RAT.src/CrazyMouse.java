/*    */ import java.awt.Dimension;
/*    */ import java.awt.Robot;
/*    */ import java.awt.Toolkit;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class CrazyMouse
/*    */ {
/*    */   public void handlePacket()
/*    */   {
/*    */     try
/*    */     {
/* 25 */       long startTime = System.currentTimeMillis();
/* 26 */       Robot r = new Robot();
/* 27 */       Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
/* 28 */       while (System.currentTimeMillis() - startTime < 8000L) {
/* 29 */         r.mouseMove(new Random().nextInt(screenSize.width), new Random().nextInt(screenSize.height));
/* 30 */         Thread.sleep(700L);
/*    */       }
/*    */     } catch (Exception e) {
/* 33 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 38 */     new CrazyMouse().handlePacket();
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     CrazyMouse
 * JD-Core Version:    0.6.2
 */