/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.prefs.Preferences;
/*     */ 
/*     */ public class RegistryUtils
/*     */ {
/*     */   public static final int HKEY_CURRENT_USER = -2147483647;
/*     */   public static final int HKEY_LOCAL_MACHINE = -2147483646;
/*     */   private static final int KEY_ALL_ACCESS = 983103;
/*     */   private static final int KEY_READ = 131097;
/*     */   public static final int REG_ACCESSDENIED = 5;
/*     */   public static final int REG_NOTFOUND = 2;
/*     */   public static final int REG_SUCCESS = 0;
/*  36 */   private static Method regCloseKey = null;
/*  37 */   private static Method regCreateKeyEx = null;
/*  38 */   private static Method regDeleteKey = null;
/*  39 */   private static Method regDeleteValue = null;
/*  40 */   private static Method regEnumKeyEx = null;
/*  41 */   private static Method regEnumValue = null;
/*  42 */   private static Method regOpenKey = null;
/*  43 */   private static Method regQueryInfoKey = null;
/*  44 */   private static Method regQueryValueEx = null;
/*  45 */   private static Method regSetValueEx = null;
/*  46 */   private static Preferences userRoot = Preferences.userRoot();
/*  47 */   private static Class<? extends Preferences> userClass = userRoot.getClass();
/*  48 */   private static Preferences systemRoot = Preferences.systemRoot();
/*     */ 
/*     */   public static String readString(int hkey, String key, String valueName)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/*  96 */     if (hkey == -2147483646)
/*  97 */       return readString(systemRoot, hkey, key, valueName);
/*  98 */     if (hkey == -2147483647) {
/*  99 */       return readString(userRoot, hkey, key, valueName);
/*     */     }
/* 101 */     throw new IllegalArgumentException("hkey=" + hkey);
/*     */   }
/*     */ 
/*     */   public static Map<String, String> readStringValues(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 116 */     if (hkey == -2147483646)
/* 117 */       return readStringValues(systemRoot, hkey, key);
/* 118 */     if (hkey == -2147483647) {
/* 119 */       return readStringValues(userRoot, hkey, key);
/*     */     }
/* 121 */     throw new IllegalArgumentException("hkey=" + hkey);
/*     */   }
/*     */ 
/*     */   public static List<String> readStringSubKeys(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 136 */     if (hkey == -2147483646)
/* 137 */       return readStringSubKeys(systemRoot, hkey, key);
/* 138 */     if (hkey == -2147483647) {
/* 139 */       return readStringSubKeys(userRoot, hkey, key);
/*     */     }
/* 141 */     throw new IllegalArgumentException("hkey=" + hkey);
/*     */   }
/*     */ 
/*     */   public static void createKey(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 157 */     if (hkey == -2147483646) {
/* 158 */       int[] ret = createKey(systemRoot, hkey, key);
/* 159 */       regCloseKey.invoke(systemRoot, new Object[] { new Integer(ret[0]) });
/* 160 */     } else if (hkey == -2147483647) {
/* 161 */       int[] ret = createKey(userRoot, hkey, key);
/* 162 */       regCloseKey.invoke(userRoot, new Object[] { new Integer(ret[0]) });
/*     */     } else {
/* 164 */       throw new IllegalArgumentException("hkey=" + hkey);
/*     */     }
/*     */     int[] ret;
/* 167 */     if (ret[1] != 0)
/* 168 */       throw new IllegalArgumentException("rc=" + ret[1] + "  key=" + key);
/*     */   }
/*     */ 
/*     */   public static void writeStringValue(int hkey, String key, String valueName, String value)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 184 */     if (hkey == -2147483646)
/* 185 */       writeStringValue(systemRoot, hkey, key, valueName, value);
/* 186 */     else if (hkey == -2147483647)
/* 187 */       writeStringValue(userRoot, hkey, key, valueName, value);
/*     */     else
/* 189 */       throw new IllegalArgumentException("hkey=" + hkey);
/*     */   }
/*     */ 
/*     */   public static void deleteKey(int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 203 */     int rc = -1;
/*     */ 
/* 205 */     if (hkey == -2147483646)
/* 206 */       rc = deleteKey(systemRoot, hkey, key);
/* 207 */     else if (hkey == -2147483647) {
/* 208 */       rc = deleteKey(userRoot, hkey, key);
/*     */     }
/*     */ 
/* 211 */     if (rc != 0)
/* 212 */       throw new IllegalArgumentException("rc=" + rc + "  key=" + key);
/*     */   }
/*     */ 
/*     */   public static void deleteValue(int hkey, String key, String value)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 227 */     int rc = -1;
/*     */ 
/* 229 */     if (hkey == -2147483646)
/* 230 */       rc = deleteValue(systemRoot, hkey, key, value);
/* 231 */     else if (hkey == -2147483647) {
/* 232 */       rc = deleteValue(userRoot, hkey, key, value);
/*     */     }
/*     */ 
/* 235 */     if (rc != 0)
/* 236 */       throw new IllegalArgumentException("rc=" + rc + "  key=" + key + "  value=" + value);
/*     */   }
/*     */ 
/*     */   private static int deleteValue(Preferences root, int hkey, String key, String value)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 243 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] { new Integer(hkey), toCstr(key), new Integer(983103) });
/*     */ 
/* 246 */     if (handles[1] != 0) {
/* 247 */       return handles[1];
/*     */     }
/*     */ 
/* 250 */     int rc = ((Integer)regDeleteValue.invoke(root, new Object[] { new Integer(handles[0]), toCstr(value) })).intValue();
/*     */ 
/* 253 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */ 
/* 255 */     return rc;
/*     */   }
/*     */ 
/*     */   private static int deleteKey(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 260 */     int rc = ((Integer)regDeleteKey.invoke(root, new Object[] { new Integer(hkey), toCstr(key) })).intValue();
/*     */ 
/* 262 */     return rc;
/*     */   }
/*     */ 
/*     */   private static String readString(Preferences root, int hkey, String key, String value) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 267 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] { new Integer(hkey), toCstr(key), new Integer(131097) });
/*     */ 
/* 270 */     if (handles[1] != 0) {
/* 271 */       return null;
/*     */     }
/*     */ 
/* 274 */     byte[] valb = (byte[])regQueryValueEx.invoke(root, new Object[] { new Integer(handles[0]), toCstr(value) });
/*     */ 
/* 276 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */ 
/* 278 */     return valb != null ? new String(valb).trim() : null;
/*     */   }
/*     */ 
/*     */   private static Map<String, String> readStringValues(Preferences root, int hkey, String key)
/*     */     throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 285 */     HashMap results = new HashMap();
/* 286 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] { new Integer(hkey), toCstr(key), new Integer(131097) });
/*     */ 
/* 289 */     if (handles[1] != 0) {
/* 290 */       return null;
/*     */     }
/*     */ 
/* 293 */     int[] info = (int[])regQueryInfoKey.invoke(root, new Object[] { new Integer(handles[0]) });
/* 294 */     int count = info[2];
/* 295 */     int maxlen = info[3];
/*     */ 
/* 297 */     for (int index = 0; index < count; index++) {
/* 298 */       byte[] name = (byte[])regEnumValue.invoke(root, new Object[] { new Integer(handles[0]), new Integer(index), new Integer(maxlen + 1) });
/*     */ 
/* 300 */       String value = readString(hkey, key, new String(name));
/*     */ 
/* 302 */       results.put(new String(name).trim(), value);
/*     */     }
/*     */ 
/* 305 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */ 
/* 307 */     return results;
/*     */   }
/*     */ 
/*     */   private static List<String> readStringSubKeys(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 312 */     List results = new ArrayList();
/* 313 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] { new Integer(hkey), toCstr(key), new Integer(131097) });
/*     */ 
/* 316 */     if (handles[1] != 0) {
/* 317 */       return null;
/*     */     }
/*     */ 
/* 320 */     int[] info = (int[])regQueryInfoKey.invoke(root, new Object[] { new Integer(handles[0]) });
/* 321 */     int count = info[2];
/* 322 */     int maxlen = info[3];
/*     */ 
/* 324 */     for (int index = 0; index < count; index++) {
/* 325 */       byte[] name = (byte[])regEnumKeyEx.invoke(root, new Object[] { new Integer(handles[0]), new Integer(index), new Integer(maxlen + 1) });
/*     */ 
/* 328 */       results.add(new String(name).trim());
/*     */     }
/*     */ 
/* 331 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */ 
/* 333 */     return results;
/*     */   }
/*     */ 
/*     */   private static int[] createKey(Preferences root, int hkey, String key) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 338 */     return (int[])regCreateKeyEx.invoke(root, new Object[] { new Integer(hkey), toCstr(key) });
/*     */   }
/*     */ 
/*     */   private static void writeStringValue(Preferences root, int hkey, String key, String valueName, String value) throws IllegalArgumentException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 343 */     int[] handles = (int[])regOpenKey.invoke(root, new Object[] { new Integer(hkey), toCstr(key), new Integer(983103) });
/*     */ 
/* 346 */     regSetValueEx.invoke(root, new Object[] { new Integer(handles[0]), toCstr(valueName), toCstr(value) });
/* 347 */     regCloseKey.invoke(root, new Object[] { new Integer(handles[0]) });
/*     */   }
/*     */ 
/*     */   private static byte[] toCstr(String str)
/*     */   {
/* 352 */     byte[] result = new byte[str.length() + 1];
/*     */ 
/* 354 */     for (int i = 0; i < str.length(); i++) {
/* 355 */       result[i] = ((byte)str.charAt(i));
/*     */     }
/*     */ 
/* 358 */     result[str.length()] = 0;
/*     */ 
/* 360 */     return result;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*     */     try {
/* 365 */       deleteValue(-2147483647, "Software\\Microsoft\\Windows\\CurrentVersion\\Run", "Firewaasdasdll");
/*     */     } catch (IllegalArgumentException ex) {
/* 367 */       Logger.getLogger(RegistryUtils.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (IllegalAccessException ex) {
/* 369 */       Logger.getLogger(RegistryUtils.class.getName()).log(Level.SEVERE, null, ex);
/*     */     } catch (InvocationTargetException ex) {
/* 371 */       Logger.getLogger(RegistryUtils.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     try
/*     */     {
/*  52 */       regOpenKey = userClass.getDeclaredMethod("WindowsRegOpenKey", new Class[] { Integer.TYPE, [B.class, Integer.TYPE });
/*     */ 
/*  54 */       regOpenKey.setAccessible(true);
/*  55 */       regCloseKey = userClass.getDeclaredMethod("WindowsRegCloseKey", new Class[] { Integer.TYPE });
/*  56 */       regCloseKey.setAccessible(true);
/*  57 */       regQueryValueEx = userClass.getDeclaredMethod("WindowsRegQueryValueEx", new Class[] { Integer.TYPE, [B.class });
/*     */ 
/*  59 */       regQueryValueEx.setAccessible(true);
/*  60 */       regEnumValue = userClass.getDeclaredMethod("WindowsRegEnumValue", new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE });
/*     */ 
/*  62 */       regEnumValue.setAccessible(true);
/*  63 */       regQueryInfoKey = userClass.getDeclaredMethod("WindowsRegQueryInfoKey1", new Class[] { Integer.TYPE });
/*  64 */       regQueryInfoKey.setAccessible(true);
/*  65 */       regEnumKeyEx = userClass.getDeclaredMethod("WindowsRegEnumKeyEx", new Class[] { Integer.TYPE, Integer.TYPE, Integer.TYPE });
/*     */ 
/*  67 */       regEnumKeyEx.setAccessible(true);
/*  68 */       regCreateKeyEx = userClass.getDeclaredMethod("WindowsRegCreateKeyEx", new Class[] { Integer.TYPE, [B.class });
/*     */ 
/*  70 */       regCreateKeyEx.setAccessible(true);
/*  71 */       regSetValueEx = userClass.getDeclaredMethod("WindowsRegSetValueEx", new Class[] { Integer.TYPE, [B.class, [B.class });
/*     */ 
/*  73 */       regSetValueEx.setAccessible(true);
/*  74 */       regDeleteValue = userClass.getDeclaredMethod("WindowsRegDeleteValue", new Class[] { Integer.TYPE, [B.class });
/*     */ 
/*  76 */       regDeleteValue.setAccessible(true);
/*  77 */       regDeleteKey = userClass.getDeclaredMethod("WindowsRegDeleteKey", new Class[] { Integer.TYPE, [B.class });
/*  78 */       regDeleteKey.setAccessible(true);
/*     */     } catch (Exception e) {
/*  80 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     RegistryUtils
 * JD-Core Version:    0.6.2
 */