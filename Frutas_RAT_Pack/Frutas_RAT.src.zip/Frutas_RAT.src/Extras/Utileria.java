/*    */ package Extras;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Toolkit;
/*    */ import java.awt.Window;
/*    */ 
/*    */ public class Utileria
/*    */ {
/*    */   public static void centraVentana(Window frame)
/*    */   {
/*  8 */     int altoPantalla = Toolkit.getDefaultToolkit().getScreenSize().height / 2;
/*  9 */     int anchoPantalla = Toolkit.getDefaultToolkit().getScreenSize().width / 2;
/* 10 */     int altoAplicacion = frame.getSize().height / 2;
/* 11 */     int anchoAplicacion = frame.getSize().width / 2;
/* 12 */     frame.setLocation(anchoPantalla - anchoAplicacion, altoPantalla - altoAplicacion);
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     Extras.Utileria
 * JD-Core Version:    0.6.2
 */