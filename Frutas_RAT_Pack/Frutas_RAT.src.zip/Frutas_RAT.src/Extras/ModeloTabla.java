/*    */ package Extras;
/*    */ 
/*    */ import javax.swing.table.DefaultTableModel;
/*    */ 
/*    */ public class ModeloTabla extends DefaultTableModel
/*    */ {
/*    */   public ModeloTabla(String[] Encabezados)
/*    */   {
/* 13 */     for (int i = 0; i < Encabezados.length; i++)
/* 14 */       addColumn(Encabezados[i]);
/*    */   }
/*    */ 
/*    */   public boolean isCellEditable(int row, int column)
/*    */   {
/* 20 */     return false;
/*    */   }
/*    */ 
/*    */   public void addFila(String[] fila)
/*    */   {
/* 26 */     addRow(fila);
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     Extras.ModeloTabla
 * JD-Core Version:    0.6.2
 */