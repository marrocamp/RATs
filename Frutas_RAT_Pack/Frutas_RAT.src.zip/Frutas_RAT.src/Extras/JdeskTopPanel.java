/*    */ package Extras;
/*    */ 
/*    */ import java.awt.Graphics;
/*    */ import java.awt.Image;
/*    */ import java.awt.Toolkit;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JDesktopPane;
/*    */ 
/*    */ public class JdeskTopPanel extends JDesktopPane
/*    */ {
/*    */   private Image m;
/*    */ 
/*    */   public JdeskTopPanel()
/*    */   {
/*    */     try
/*    */     {
/* 20 */       File tmp = new File("Imagenes/background.png");
/* 21 */       if (tmp.exists())
/* 22 */         this.m = Toolkit.getDefaultToolkit().getImage("Imagenes/background.png");
/*    */       else {
/* 24 */         this.m = new ImageIcon(getClass().getResource("/resources/backgro2.jpg")).getImage();
/*    */       }
/* 26 */       System.out.println(this.m.getHeight(null));
/*    */     } catch (Exception e) {
/* 28 */       System.out.println(e.getMessage());
/*    */     }
/*    */   }
/*    */ 
/*    */   public void paint(Graphics g)
/*    */   {
/* 34 */     if (this.m != null)
/*    */     {
/* 36 */       g.drawImage(this.m, 0, 0, getWidth(), getHeight(), this);
/* 37 */       setOpaque(false);
/*    */     } else {
/* 39 */       setOpaque(true);
/*    */     }
/* 41 */     super.paint(g);
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     Extras.JdeskTopPanel
 * JD-Core Version:    0.6.2
 */