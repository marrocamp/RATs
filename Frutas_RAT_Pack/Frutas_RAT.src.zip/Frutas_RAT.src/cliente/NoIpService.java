/*    */ package cliente;
/*    */ 
/*    */ import java.io.BufferedReader;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStreamReader;
/*    */ import java.io.PrintStream;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URL;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public class NoIpService
/*    */ {
/*    */   private String user;
/*    */   private String pass;
/*    */ 
/*    */   public NoIpService(String user, String pass)
/*    */   {
/* 16 */     this.user = user;
/* 17 */     this.pass = pass;
/*    */   }
/*    */ 
/*    */   public String[] getDNS() {
/* 21 */     String[] DNS = null;
/*    */     try {
/* 23 */       HttpURLConnection conexion = (HttpURLConnection)new URL("http://dynupdate.no-ip.com/list-hosts.php?email=" + this.user + "&pass=" + this.pass).openConnection();
/* 24 */       BufferedReader br = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
/* 25 */       String t = "";
/* 26 */       while (br.ready()) {
/* 27 */         t = br.readLine();
/*    */       }
/* 29 */       if (t.contains("=")) {
/* 30 */         return null;
/*    */       }
/* 32 */       t = t.replace("#,", "");
/* 33 */       return t.split(Pattern.quote("|"));
/*    */     }
/*    */     catch (IOException ex) {
/*    */     }
/* 37 */     return DNS;
/*    */   }
/*    */ 
/*    */   public String actualiza(String DNS, String ip) {
/* 41 */     String texto = "Ocurrio un error";
/* 42 */     String URL = "http://dynupdate.no-ip.com/dns?username=" + this.user + "&password=" + this.pass + "&hostname=" + DNS;
/* 43 */     if (!ip.equals(""))
/* 44 */       URL = URL + "&ip=" + ip;
/*    */     try
/*    */     {
/* 47 */       HttpURLConnection conexion = (HttpURLConnection)new URL(URL).openConnection();
/* 48 */       BufferedReader br = new BufferedReader(new InputStreamReader(conexion.getInputStream()));
/* 49 */       String resultado = br.readLine();
/* 50 */       conexion.disconnect();
/* 51 */       String[] dato = resultado.split(":");
/* 52 */       int valor = Integer.parseInt(dato[1]);
/* 53 */       switch (valor) {
/*    */       case 0:
/* 55 */         texto = "Sin cambios";
/* 56 */         break;
/*    */       case 1:
/* 58 */         texto = "Actualizado";
/*    */       }
/*    */     }
/*    */     catch (Exception ex) {
/* 62 */       System.out.println(ex.getMessage());
/*    */     }
/* 64 */     return texto;
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.NoIpService
 * JD-Core Version:    0.6.2
 */