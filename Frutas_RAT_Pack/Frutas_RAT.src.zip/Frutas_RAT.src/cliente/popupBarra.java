/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.Frame;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ 
/*     */ public class popupBarra extends JDialog
/*     */   implements Runnable
/*     */ {
/*     */   int ancho;
/*     */   int alto;
/*     */   public JLabel ip;
/*     */   private JLabel ip2;
/*     */   private JPanel jPanel1;
/*     */ 
/*     */   public popupBarra(Frame parent, boolean modal)
/*     */   {
/*  21 */     super(parent, modal);
/*  22 */     setUndecorated(true);
/*  23 */     initComponents();
/*     */ 
/*  25 */     setAlwaysOnTop(true);
/*  26 */     Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
/*  27 */     this.ancho = d.width;
/*  28 */     this.alto = d.height;
/*  29 */     setLocation(this.ancho - 179, this.alto);
/*     */ 
/*  31 */     start();
/*     */   }
/*     */ 
/*     */   private void start() {
/*  35 */     Thread m = new Thread(this);
/*  36 */     m.start();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  47 */     this.jPanel1 = new JPanel();
/*  48 */     this.ip = new JLabel();
/*  49 */     this.ip2 = new JLabel();
/*     */ 
/*  51 */     setDefaultCloseOperation(2);
/*     */ 
/*  53 */     this.jPanel1.setBackground(new Color(0, 102, 51));
/*  54 */     this.jPanel1.setBorder(BorderFactory.createMatteBorder(3, 3, 3, 3, new Color(255, 102, 0)));
/*  55 */     this.jPanel1.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/*  57 */         popupBarra.this.jPanel1MouseClicked(evt);
/*     */       }
/*     */       public void mousePressed(MouseEvent evt) {
/*  60 */         popupBarra.this.jPanel1MousePressed(evt);
/*     */       }
/*     */     });
/*  64 */     this.ip.setFont(new Font("Times New Roman", 1, 14));
/*  65 */     this.ip.setText("IP: ");
/*     */ 
/*  67 */     this.ip2.setFont(new Font("Tempus Sans ITC", 1, 14));
/*  68 */     this.ip2.setText("Frutas RAT");
/*     */ 
/*  70 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/*  71 */     this.jPanel1.setLayout(jPanel1Layout);
/*  72 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addGap(0, 16, 32767).addComponent(this.ip2).addGap(48, 48, 48)).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addComponent(this.ip, -1, -1, 32767).addContainerGap()))));
/*     */ 
/*  85 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addGap(27, 27, 27).addComponent(this.ip).addGap(18, 18, 18).addComponent(this.ip2).addContainerGap(-1, 32767)));
/*     */ 
/*  95 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  96 */     getContentPane().setLayout(layout);
/*  97 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -2, -1, -2));
/*     */ 
/* 101 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -2, -1, -2));
/*     */ 
/* 106 */     pack();
/*     */   }
/*     */ 
/*     */   private void jPanel1MouseClicked(MouseEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void jPanel1MousePressed(MouseEvent evt) {
/* 114 */     dispose();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 136 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 139 */         popupBarra dialog = new popupBarra(new JFrame(), false);
/* 140 */         dialog.addWindowListener(new WindowAdapter()
/*     */         {
/*     */           public void windowClosing(WindowEvent e)
/*     */           {
/* 144 */             System.exit(0);
/*     */           }
/*     */         });
/* 147 */         dialog.setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/* 160 */       for (int i = 0; i <= 160; i++) {
/* 161 */         setLocation(this.ancho - 179, this.alto - i);
/* 162 */         setAlwaysOnTop(true);
/* 163 */         Thread.sleep(15L);
/*     */       }
/*     */ 
/* 166 */       Thread.sleep(2000L);
/* 167 */       dispose();
/*     */     }
/*     */     catch (InterruptedException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.popupBarra
 * JD-Core Version:    0.6.2
 */