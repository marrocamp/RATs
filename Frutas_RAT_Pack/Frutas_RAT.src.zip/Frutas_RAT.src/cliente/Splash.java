/*    */ package cliente;
/*    */ 
/*    */ import java.awt.Color;
/*    */ import java.awt.Container;
/*    */ import java.awt.EventQueue;
/*    */ import java.awt.event.MouseAdapter;
/*    */ import java.awt.event.MouseEvent;
/*    */ import javax.swing.GroupLayout;
/*    */ import javax.swing.GroupLayout.Alignment;
/*    */ import javax.swing.GroupLayout.ParallelGroup;
/*    */ import javax.swing.ImageIcon;
/*    */ import javax.swing.JFrame;
/*    */ import javax.swing.JLabel;
/*    */ 
/*    */ public class Splash extends JFrame
/*    */   implements Runnable
/*    */ {
/*    */   private JLabel jLabel1;
/*    */ 
/*    */   public Splash()
/*    */   {
/* 20 */     initComponents();
/* 21 */     setLocationRelativeTo(null);
/* 22 */     new Thread(this).start();
/*    */   }
/*    */ 
/*    */   private void initComponents()
/*    */   {
/* 34 */     this.jLabel1 = new JLabel();
/*    */ 
/* 36 */     setDefaultCloseOperation(3);
/* 37 */     setUndecorated(true);
/*    */ 
/* 39 */     this.jLabel1.setBackground(new Color(0, 102, 51));
/* 40 */     this.jLabel1.setIcon(new ImageIcon(getClass().getResource("/resources/FrutasRAT-1.png")));
/* 41 */     this.jLabel1.setOpaque(true);
/* 42 */     this.jLabel1.addMouseListener(new MouseAdapter() {
/*    */       public void mousePressed(MouseEvent evt) {
/* 44 */         Splash.this.jLabel1MousePressed(evt);
/*    */       }
/*    */     });
/* 48 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 49 */     getContentPane().setLayout(layout);
/* 50 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel1));
/*    */ 
/* 54 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel1));
/*    */ 
/* 59 */     pack();
/*    */   }
/*    */ 
/*    */   private void jLabel1MousePressed(MouseEvent evt)
/*    */   {
/*    */   }
/*    */ 
/*    */   public static void main(String[] args)
/*    */   {
/* 82 */     EventQueue.invokeLater(new Runnable() {
/*    */       public void run() {
/* 84 */         new Splash().setVisible(true);
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 95 */       Thread.sleep(2000L);
/* 96 */       setVisible(false);
/* 97 */       Disclaimer.main(null);
/*    */     }
/*    */     catch (InterruptedException ex)
/*    */     {
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Splash
 * JD-Core Version:    0.6.2
 */