/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import javax.swing.ButtonGroup;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class funOpcion extends JInternalFrame
/*     */ {
/*     */   private ButtonGroup buttonGroup1;
/*     */   private JButton jButton1;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JRadioButton jRadioButton1;
/*     */   private JRadioButton jRadioButton2;
/*     */   private JSpinner jSpinner1;
/*     */   private JTextField jTextField2;
/*     */ 
/*     */   public funOpcion()
/*     */   {
/*  17 */     initComponents();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  29 */     this.buttonGroup1 = new ButtonGroup();
/*  30 */     this.jRadioButton1 = new JRadioButton();
/*  31 */     this.jLabel1 = new JLabel();
/*  32 */     this.jTextField2 = new JTextField();
/*  33 */     this.jLabel2 = new JLabel();
/*  34 */     this.jRadioButton2 = new JRadioButton();
/*  35 */     this.jButton1 = new JButton();
/*  36 */     this.jSpinner1 = new JSpinner();
/*     */ 
/*  38 */     setClosable(true);
/*  39 */     setIconifiable(true);
/*     */ 
/*  41 */     this.buttonGroup1.add(this.jRadioButton1);
/*  42 */     this.jRadioButton1.setText("Apagar");
/*     */ 
/*  44 */     this.jLabel1.setFont(new Font("Times New Roman", 1, 14));
/*  45 */     this.jLabel1.setText("Tiempo (s): ");
/*     */ 
/*  47 */     this.jTextField2.setText("10 segundo");
/*     */ 
/*  49 */     this.jLabel2.setFont(new Font("Times New Roman", 1, 14));
/*  50 */     this.jLabel2.setText("Mensaje: ");
/*     */ 
/*  52 */     this.buttonGroup1.add(this.jRadioButton2);
/*  53 */     this.jRadioButton2.setSelected(true);
/*  54 */     this.jRadioButton2.setText("Reiniciar");
/*     */ 
/*  56 */     this.jButton1.setText("Ejecutar acción");
/*     */ 
/*  58 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  59 */     getContentPane().setLayout(layout);
/*  60 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jSpinner1, -2, 52, -2).addComponent(this.jLabel1).addComponent(this.jRadioButton2, -2, 89, -2)).addGap(18, 18, 18).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(0, 0, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel2).addComponent(this.jTextField2, -2, 115, -2))).addComponent(this.jRadioButton1, -1, -1, 32767))).addGroup(layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jButton1))).addContainerGap()));
/*     */ 
/*  83 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jRadioButton2).addComponent(this.jRadioButton1)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 4, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel1).addComponent(this.jLabel2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jSpinner1, -2, -1, -2).addComponent(this.jTextField2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 7, 32767).addComponent(this.jButton1).addContainerGap(12, 32767)));
/*     */ 
/* 103 */     pack();
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.funOpcion
 * JD-Core Version:    0.6.2
 */