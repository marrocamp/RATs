package cliente;

import java.util.ResourceBundle;

public abstract interface SoporteLenguaje
{
  public abstract void changeLenguage(ResourceBundle paramResourceBundle);
}

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.SoporteLenguaje
 * JD-Core Version:    0.6.2
 */