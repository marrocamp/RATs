/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public final class Acerca extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel5;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JTextField jTextField1;
/*     */   private JTextField jTextField2;
/*     */   private JTextField jTextField3;
/*     */   private JTextField jTextField4;
/*     */ 
/*     */   public Acerca(ResourceBundle rb)
/*     */   {
/*  19 */     initComponents();
/*  20 */     this.jTextField1.setEditable(false);
/*  21 */     this.jTextField2.setEditable(false);
/*  22 */     this.jTextField3.setEditable(false);
/*  23 */     this.jTextField4.setEditable(false);
/*     */ 
/*  25 */     changeLenguage(rb);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  37 */     this.jLabel1 = new JLabel();
/*  38 */     this.jLabel4 = new JLabel();
/*  39 */     this.jTextField1 = new JTextField();
/*  40 */     this.jLabel5 = new JLabel();
/*  41 */     this.jTextField2 = new JTextField();
/*  42 */     this.jLabel6 = new JLabel();
/*  43 */     this.jTextField3 = new JTextField();
/*  44 */     this.jTextField4 = new JTextField();
/*  45 */     this.jLabel7 = new JLabel();
/*     */ 
/*  47 */     setClosable(true);
/*  48 */     setTitle("Acerca");
/*  49 */     setToolTipText("");
/*  50 */     setFont(new Font("Andalus", 0, 10));
/*  51 */     setFrameIcon(null);
/*     */ 
/*  53 */     this.jLabel1.setFont(new Font("Times New Roman", 1, 18));
/*  54 */     this.jLabel1.setForeground(new Color(204, 102, 0));
/*  55 */     this.jLabel1.setText("Frutas R.A.T.");
/*     */ 
/*  57 */     this.jLabel4.setFont(new Font("Angelina", 1, 18));
/*  58 */     this.jLabel4.setForeground(new Color(0, 102, 51));
/*  59 */     this.jLabel4.setText("Autor: ");
/*     */ 
/*  61 */     this.jTextField1.setBackground(new Color(255, 255, 102));
/*  62 */     this.jTextField1.setFont(new Font("Times New Roman", 1, 18));
/*  63 */     this.jTextField1.setForeground(new Color(0, 102, 51));
/*  64 */     this.jTextField1.setText("Adwind");
/*     */ 
/*  66 */     this.jLabel5.setFont(new Font("Angelina", 1, 18));
/*  67 */     this.jLabel5.setForeground(new Color(0, 102, 51));
/*  68 */     this.jLabel5.setText("Pagina: ");
/*     */ 
/*  70 */     this.jTextField2.setBackground(new Color(255, 255, 102));
/*  71 */     this.jTextField2.setFont(new Font("Times New Roman", 1, 18));
/*  72 */     this.jTextField2.setForeground(new Color(0, 102, 51));
/*  73 */     this.jTextField2.setText("www.indetectables.net");
/*     */ 
/*  75 */     this.jLabel6.setFont(new Font("Angelina", 1, 18));
/*  76 */     this.jLabel6.setForeground(new Color(0, 102, 51));
/*  77 */     this.jLabel6.setText("Versión: ");
/*     */ 
/*  79 */     this.jTextField3.setBackground(new Color(255, 255, 102));
/*  80 */     this.jTextField3.setFont(new Font("Times New Roman", 1, 18));
/*  81 */     this.jTextField3.setForeground(new Color(0, 102, 51));
/*  82 */     this.jTextField3.setText("0.8");
/*     */ 
/*  84 */     this.jTextField4.setBackground(new Color(255, 255, 102));
/*  85 */     this.jTextField4.setFont(new Font("Angelina", 1, 18));
/*  86 */     this.jTextField4.setForeground(new Color(0, 102, 51));
/*  87 */     this.jTextField4.setText("Publico");
/*     */ 
/*  89 */     this.jLabel7.setFont(new Font("Angelina", 1, 18));
/*  90 */     this.jLabel7.setForeground(new Color(0, 102, 51));
/*  91 */     this.jLabel7.setText("Tipo: ");
/*  92 */     this.jLabel7.setOpaque(true);
/*     */ 
/*  94 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  95 */     getContentPane().setLayout(layout);
/*  96 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jLabel6).addComponent(this.jLabel7)).addGap(18, 18, 18)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel5).addGap(27, 27, 27))).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addComponent(this.jTextField2).addComponent(this.jTextField3).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(3, 3, 3).addComponent(this.jTextField4, -2, 173, -2)))).addGroup(layout.createSequentialGroup().addComponent(this.jLabel4).addGap(38, 38, 38).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1).addGap(0, 0, 32767)).addComponent(this.jTextField1)))).addContainerGap(94, 32767)));
/*     */ 
/* 127 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1, -2, 22, -2).addGap(12, 12, 12).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel4).addComponent(this.jTextField1, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jTextField2, -2, -1, -2).addComponent(this.jLabel5)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel6).addComponent(this.jTextField3, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTextField4, -2, -1, -2).addComponent(this.jLabel7)).addGap(0, 75, 32767)));
/*     */ 
/* 150 */     pack();
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rb)
/*     */   {
/* 167 */     setTitle(rb.getString("acerca.titulo"));
/* 168 */     this.jLabel4.setText(rb.getString("acerca.autor"));
/* 169 */     this.jLabel5.setText(rb.getString("acerca.pagina"));
/* 170 */     this.jLabel6.setText(rb.getString("acerca.version"));
/* 171 */     this.jLabel7.setText(rb.getString("acerca.tipo"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Acerca
 * JD-Core Version:    0.6.2
 */