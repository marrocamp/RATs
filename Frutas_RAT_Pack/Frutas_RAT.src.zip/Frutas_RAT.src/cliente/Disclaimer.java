/*     */ package cliente;
/*     */ 
/*     */ import Extras.Utileria;
/*     */ import java.awt.Container;
/*     */ import java.awt.EventQueue;
/*     */ import java.awt.Font;
/*     */ import java.awt.Frame;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JEditorPane;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.Timer;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ public class Disclaimer extends JDialog
/*     */ {
/*  22 */   int i = 20000; int punto = 0;
/*  23 */   Timer m = new Timer(1000, new ActionListener()
/*     */   {
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/*  28 */       Disclaimer.this.i -= 1000;
/*  29 */       Disclaimer.this.acept.setText("Aceptar (" + Disclaimer.this.i / 1000 + ")");
/*  30 */       if (Disclaimer.this.i == 0) {
/*  31 */         Disclaimer.this.m.stop();
/*  32 */         Disclaimer.this.acept.setText("Aceptar");
/*  33 */         Disclaimer.this.acept.setEnabled(true);
/*     */       }
/*     */     } } );
/*     */   private JButton acept;
/*     */   private JButton jButton2;
/*     */   private JEditorPane jEditorPane1;
/*     */   private JScrollPane jScrollPane1;
/*     */ 
/*  45 */   public Disclaimer(Frame parent, boolean modal) { super(parent, modal);
/*  46 */     initComponents();
/*  47 */     Utileria.centraVentana(this);
/*  48 */     this.m.start();
/*  49 */     this.jEditorPane1.setEditable(false);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  62 */     this.jScrollPane1 = new JScrollPane();
/*  63 */     this.jEditorPane1 = new JEditorPane();
/*  64 */     this.acept = new JButton();
/*  65 */     this.jButton2 = new JButton();
/*     */ 
/*  67 */     setDefaultCloseOperation(2);
/*  68 */     setTitle("Declaración de Privacidad");
/*     */ 
/*  70 */     this.jEditorPane1.setContentType("text/html");
/*  71 */     this.jEditorPane1.setEditable(false);
/*  72 */     this.jEditorPane1.setFont(new Font("Baskerville Old Face", 0, 11));
/*  73 */     this.jEditorPane1.setText("<html>\n<sTRONG><CENTER><h1>Frutas R.A.T.</h1></CENTER></STRONG>\n<b><i><u>Contrato entre tu(usuario final) y el autor de esta herramienta</u></i> </b>\n<ol>\n<li>Esta herramienta es desarrollada con fines educativos.</li>\n<li>Queda prohibido el mal uso de este software, todo daño causado con la misma queda a responsabilidad\ndel usuario final.</li>\n<li>Si se hace uso de esta herramienta, debe existir un acuerdo entre los dueños de los aparatos de computo involucrados</li>\n<li>Queda prohibido la reproducción total o parcial del contenido del software.</li>\n<li>Queda prohibido la ingenieria inversa de esta herramienta.</li>\n<li>Si se desea reproducir este software en otras paginas web, deben contactar al autor de esta herramienta.</li>\n</ol>\n<strong>Nota: Este contrato puede cambiar sin previo aviso del usuario final.</strong>\n</html>");
/*  74 */     this.jEditorPane1.setCaretPosition(1);
/*  75 */     this.jScrollPane1.setViewportView(this.jEditorPane1);
/*     */ 
/*  77 */     this.acept.setText("Aceptar(20)");
/*  78 */     this.acept.setEnabled(false);
/*  79 */     this.acept.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  81 */         Disclaimer.this.aceptActionPerformed(evt);
/*     */       }
/*     */     });
/*  85 */     this.jButton2.setText("Cerrar");
/*  86 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  88 */         Disclaimer.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/*  92 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  93 */     getContentPane().setLayout(layout);
/*  94 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -1, 522, 32767)).addGroup(layout.createSequentialGroup().addGap(141, 141, 141).addComponent(this.acept).addGap(34, 34, 34).addComponent(this.jButton2).addGap(0, 0, 32767))).addContainerGap()));
/*     */ 
/* 109 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane1, -2, 322, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.acept).addComponent(this.jButton2)).addContainerGap(16, 32767)));
/*     */ 
/* 120 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt) {
/* 124 */     dispose();
/* 125 */     System.exit(0);
/*     */   }
/*     */ 
/*     */   private void aceptActionPerformed(ActionEvent evt)
/*     */   {
/* 130 */     FrutaManager.main(null);
/* 131 */     File disclaimer = new File("Disclaimer.txt");
/*     */     try {
/* 133 */       disclaimer.createNewFile();
/*     */     } catch (IOException ex) {
/* 135 */       Logger.getLogger(Disclaimer.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */ 
/* 139 */     dispose();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*     */     try
/*     */     {
/* 155 */       UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
/* 156 */       UIManager.put("AuditoryCues.playList", UIManager.get("AuditoryCues.allAuditoryCues"));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*     */ 
/* 164 */     if (new File("Disclaimer.txt").exists())
/* 165 */       FrutaManager.main(null);
/*     */     else
/* 167 */       EventQueue.invokeLater(new Runnable()
/*     */       {
/*     */         public void run() {
/* 170 */           Disclaimer dialog = new Disclaimer(new JFrame(), true);
/*     */ 
/* 172 */           dialog.addWindowListener(new WindowAdapter()
/*     */           {
/*     */             public void windowClosing(WindowEvent e)
/*     */             {
/* 176 */               System.exit(0);
/*     */             }
/*     */           });
/* 179 */           dialog.setVisible(true);
/*     */         }
/*     */       });
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Disclaimer
 * JD-Core Version:    0.6.2
 */