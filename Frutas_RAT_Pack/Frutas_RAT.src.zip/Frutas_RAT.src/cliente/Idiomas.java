/*    */ package cliente;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.event.MouseAdapter;
/*    */ import java.awt.event.MouseEvent;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Locale;
/*    */ import java.util.ResourceBundle;
/*    */ import javax.swing.DefaultListModel;
/*    */ import javax.swing.GroupLayout;
/*    */ import javax.swing.GroupLayout.Alignment;
/*    */ import javax.swing.GroupLayout.ParallelGroup;
/*    */ import javax.swing.GroupLayout.SequentialGroup;
/*    */ import javax.swing.JInternalFrame;
/*    */ import javax.swing.JList;
/*    */ import javax.swing.JScrollPane;
/*    */ 
/*    */ public class Idiomas extends JInternalFrame
/*    */ {
/*    */   private FrutaManager f;
/*    */   private JScrollPane jScrollPane1;
/*    */   private JList leng;
/*    */ 
/*    */   public Idiomas(FrutaManager m)
/*    */   {
/* 21 */     this.f = m;
/* 22 */     initComponents();
/* 23 */     DefaultListModel list = (DefaultListModel)this.leng.getModel();
/* 24 */     int i = 0;
/*    */     try {
/*    */       while (true) {
/* 27 */         ResourceBundle rb = ResourceBundle.getBundle("idiomas/" + i, Locale.getDefault());
/* 28 */         list.addElement(rb.getString("idioma.nombre"));
/*    */ 
/* 30 */         i++;
/*    */       }
/*    */     } catch (Exception e) {
/* 33 */       System.out.println("Termine de cargar los idiomas");
/*    */     }
/*    */   }
/*    */ 
/*    */   private void initComponents()
/*    */   {
/* 47 */     this.jScrollPane1 = new JScrollPane();
/* 48 */     this.leng = new JList();
/*    */ 
/* 50 */     setClosable(true);
/* 51 */     setIconifiable(true);
/*    */ 
/* 53 */     this.leng.setModel(new DefaultListModel());
/* 54 */     this.leng.setSelectionMode(0);
/* 55 */     this.leng.addMouseListener(new MouseAdapter() {
/*    */       public void mouseClicked(MouseEvent evt) {
/* 57 */         Idiomas.this.lengMouseClicked(evt);
/*    */       }
/*    */     });
/* 60 */     this.jScrollPane1.setViewportView(this.leng);
/*    */ 
/* 62 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 63 */     getContentPane().setLayout(layout);
/* 64 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -2, 135, -2).addContainerGap(-1, 32767)));
/*    */ 
/* 71 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -1, 264, 32767).addContainerGap()));
/*    */ 
/* 79 */     pack();
/*    */   }
/*    */ 
/*    */   private void lengMouseClicked(MouseEvent evt)
/*    */   {
/* 84 */     ResourceBundle rb = ResourceBundle.getBundle("idiomas/" + this.leng.getSelectedIndex(), Locale.getDefault());
/*    */ 
/* 86 */     this.f.setIdioma(rb);
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Idiomas
 * JD-Core Version:    0.6.2
 */