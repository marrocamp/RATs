/*    */ package cliente;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import java.awt.Font;
/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import javax.swing.GroupLayout;
/*    */ import javax.swing.GroupLayout.Alignment;
/*    */ import javax.swing.GroupLayout.ParallelGroup;
/*    */ import javax.swing.GroupLayout.SequentialGroup;
/*    */ import javax.swing.JInternalFrame;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTextArea;
/*    */ 
/*    */ public class PassFileZilla extends JInternalFrame
/*    */ {
/*    */   private Usuario user;
/*    */   private DataOutputStream sal;
/*    */   private DataInputStream ent;
/*    */   private JScrollPane jScrollPane1;
/*    */   private JTextArea jTextArea1;
/*    */ 
/*    */   public PassFileZilla(Usuario us, String pass)
/*    */   {
/* 27 */     initComponents();
/* 28 */     this.user = us;
/* 29 */     setTitle(getTitle() + this.user.getIdentificador());
/*    */ 
/* 37 */     this.jTextArea1.setText(pass);
/*    */   }
/*    */ 
/*    */   private void initComponents()
/*    */   {
/* 49 */     this.jScrollPane1 = new JScrollPane();
/* 50 */     this.jTextArea1 = new JTextArea();
/*    */ 
/* 52 */     setClosable(true);
/* 53 */     setIconifiable(true);
/* 54 */     setResizable(true);
/* 55 */     setTitle("Contraseñas: ");
/*    */ 
/* 57 */     this.jTextArea1.setColumns(20);
/* 58 */     this.jTextArea1.setFont(new Font("Times New Roman", 1, 14));
/* 59 */     this.jTextArea1.setRows(5);
/* 60 */     this.jScrollPane1.setViewportView(this.jTextArea1);
/*    */ 
/* 62 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 63 */     getContentPane().setLayout(layout);
/* 64 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(GroupLayout.Alignment.TRAILING, layout.createSequentialGroup().addGap(0, 0, 0).addComponent(this.jScrollPane1, -1, 321, 32767)));
/*    */ 
/* 70 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -1, 210, 32767));
/*    */ 
/* 75 */     pack();
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.PassFileZilla
 * JD-Core Version:    0.6.2
 */