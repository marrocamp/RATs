/*    */ package cliente;
/*    */ 
/*    */ import java.awt.Container;
/*    */ import javax.swing.GroupLayout;
/*    */ import javax.swing.GroupLayout.Alignment;
/*    */ import javax.swing.GroupLayout.ParallelGroup;
/*    */ import javax.swing.GroupLayout.SequentialGroup;
/*    */ import javax.swing.JButton;
/*    */ import javax.swing.JInternalFrame;
/*    */ import javax.swing.JScrollPane;
/*    */ import javax.swing.JTable;
/*    */ import javax.swing.LayoutStyle.ComponentPlacement;
/*    */ import javax.swing.table.DefaultTableModel;
/*    */ 
/*    */ public class Procesos extends JInternalFrame
/*    */ {
/*    */   private JButton jButton1;
/*    */   private JButton jButton2;
/*    */   private JScrollPane jScrollPane1;
/*    */   private JTable jTable1;
/*    */ 
/*    */   public Procesos()
/*    */   {
/* 17 */     initComponents();
/*    */   }
/*    */ 
/*    */   private void initComponents()
/*    */   {
/* 29 */     this.jScrollPane1 = new JScrollPane();
/* 30 */     this.jTable1 = new JTable();
/* 31 */     this.jButton1 = new JButton();
/* 32 */     this.jButton2 = new JButton();
/*    */ 
/* 34 */     this.jTable1.setModel(new DefaultTableModel(new Object[0][], new String[] { "Nombre de Imagen", "PID", "Nombre de Sesión", "Uso de Memoria" }));
/*    */ 
/* 42 */     this.jScrollPane1.setViewportView(this.jTable1);
/*    */ 
/* 44 */     this.jButton1.setText("Listar");
/*    */ 
/* 46 */     this.jButton2.setText("Matar");
/*    */ 
/* 48 */     GroupLayout layout = new GroupLayout(getContentPane());
/* 49 */     getContentPane().setLayout(layout);
/* 50 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jScrollPane1, -1, 624, 32767).addGroup(layout.createSequentialGroup().addComponent(this.jButton1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton2).addGap(0, 0, 32767)))));
/*    */ 
/* 62 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addComponent(this.jScrollPane1, -2, 251, -2).addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE).addComponent(this.jButton1).addComponent(this.jButton2)).addContainerGap(-1, 32767)));
/*    */ 
/* 74 */     pack();
/*    */   }
/*    */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Procesos
 * JD-Core Version:    0.6.2
 */