ENGLISH :
PLEASE READ THIS INFORMATION BEFORE USING Pr0rAt :
----------------------------------------------------------------------------------

1- Before using Pr0rAt please read the help file. You can reach to the help file by pressing on the  �?� sign which is just on the top of the Pr0rAt client. As you will see there is enough information there for use and solving your problems. 

2- All kind of user problems with Pr0rAt are discussed in http://www.Pr0rAt.net/forum 
Before writing to the form we suggest you to read the help file once more and if you can't find the answer in the help file write it to the form under the right topic correctly with details such as your operating system, error message etc. so we can solve the problem fast and properly. We don�t answer any kind of questions like "why cant i connect to the server what should I do?"

3- You cannot start Pr0rAt directly in a zip file first you must unzip and then you can start the client. This is not a error this is just made to work Pr0rAt properly.

4- To connect to a PC with Pr0rAt client the server should not have to be directly connected to internet. so if the PC is behind a network and has a IP address like �192.168.0.*  or if its behind a Router and has a IP like �10.*.*.*  you will beable to connect with Pr0rAt, you must be a Special Edition user to do this process. Public Edition users can not use reverse connection to connect to PC 's behind networks and routers. You can only use Reverse Connection feature which you can connect to PC's which are behind networks and routers in Pr0rAt Special Edition .

5- Pr0rAt will not send any keylogg files or any passwords to your email address. Pr0rAt is a "ProHack Remote Administrator Tool" you can only get the keylogg files and passwords you want to learn by connect to the victims PC.

6- You can connect to all PC in your country and other country�s as well. If the victim is connected to internet this will be enough 

7- If you cant connect to a victim this doesn�t mean that you cannot connect to all victims. Please try new victims and you will see that it will connect. If you still cant connect to a victim after trying few times read the help file and try to find where you are making a mistake and feel free to ask us questions if you still have problems.
 
8- If your or your victims PC is being forced to closing after you started Pr0rAt server or ProConnective this is not Pr0rAt fault because some kind of worm virus like msblast can infiltrate to PC which doesn�t have security patches. Pr0rAt will close the Firewall (optional) and this will give a chance to this kind of worms to infiltrate and close systems. To take measures please read the help file and you will see links to download patch files.

9- if you try to make Pr0rAt server undetectable to AntiVirus the Pr0rAt will not connect to the server. If you want a server which is undetectable from AntiVirus you must buy Pr0rAt Special Edition, For more information please get in contact with sale@prohack.net.
If you didn�t try to change server and you still get a connection reject message, possibly the server wasn�t installed properly to the victims PC

10- Please attach importance to the Online News on you client. You will find important messages and news about Pr0rAt and ProGroup. Sometimes Online news would not work and this does not mean it wont work forever. Try few days later because during updates and server problems it could be closed.
----------------------------------------------------------------------------------
__________________________________________________________________________________



TURKISH:
Pr0rAt'� KULLANMAYA BA�LAMADAN �NCE MUTLAKA BURADA YAZANLARI OKUYUNUZ :
----------------------------------------------------------------------------------

1- Pr0rAt'� kullanmaya ba�lamadan �nce mutlaka yard�m dosyas�n� iyice okuyun. Pr0rAt'�n yard�m dosyas�na Pr0rAt clientini �al��t�rd�ktan sonra client �zerinde sa� �stte bulunan "?" Soru ��areti butonuna t�klayarak eri�ebilirsiniz. Pr0rAt'�n yard�m dosyas�nda ihtiya� duyabilece�iniz t�m bilgiler yer almaktad�r.

2- Pr0rAt ile ilgili sorunlar bu adresteki :
http://www.Pr0rAt.net/forum forumlar�nda tart���lmaktad�r. Bu forumda yazanlar ile Pr0rAt�n  yard�m dosyas� iyice okunmadan foruma soru sorulmamas�n� rica ediyoruz. Ayr�ca sorular�n�zda l�tfen yeterli a��klama ve i�letim sistemi hata mesaj� vs vs gibi detaylar yer als�n. "Eee ben ba�lanam�om neden" �eklindeki sorular ciddiye al�nmayacakt�r.

3- Pr0rAt� direkt olarak zip dosyas�ndan �al��t�ramazs�n�z. �nce zipten ��kart�n sonra �al��t�r�n. Bu bir hata de�ildir. Program�n stabil �al��abilmesi i�in yap�lm��t�r.

4- Pr0rAt clienti ile bir bilgisayara ba�lanabilmeniz i�in o PC'nin nete direk ��k�� yapmas� gerekmez. Yani a� i�inde 192.168.0.* t�r�nde ip adresi olan istemci PC'lere yada Router arkas�nda bulunan ve 10.*.*.* t�r�nde ip lere sahip olan PC'lere de Pr0rAt ile ba�lanabilirsiniz. Ancak bunu yapabilmek i�in Pr0rAt Special Edition sahibi olman�z gerekir. Free Pr0rAt kullan�c�lar� reverse connection �zelli�inden faydalanarak a� i�i ve router arkas�ndaki pc lere ba�lanamazlar. Reverse connection ba�lant� kurarak a� i�i ve router arkas�nda ki PC'lere ba�lanmak Pr0rAt Special Editiona has bir �zelliktir.

5- Pr0rAt mailinize �ifre keylog vs t�r�nde bilgiler g�ndermez. ��nk� Pr0rAt yani "ProHack Remote Administrator Tool" bir uzaktan y�netim program�d�r. �ifreleri ve keylog kay�tlar�n� maile yollamas� i�in yap�lmad�. �ifreleri ele ge�irmek isteyenler ba�lanarak almal�.

6- Pr0rAt yurt i�ine ba�lan�r yurt d���na ba�lanmaz yada tam tersi �eklinde bir �ey s�z konusu de�ildir. Internet'e ba�lanan PC' ayda bile olsa yeterli ba�lant� h�z�na sahipse Pr0rAt ile ba�lanabilirsiniz.

7- Bir kurbana ba�lanamam�� olman�z her kurbana ba�lanamayaca��n�z anlam�na gelmez. L�tfen bu t�r gereksiz sorularla bizleri me�gul etmeyin Pr0rAt clienti ile o kurbana ba�lanamad�ysan�z yeni kurbanlar deneyin. Zira Pr0rAt Serverlar�na sorunsuz ba�lanabiliyor. Fakat birden fazla kurbana ba�lanam�yorsan�z. Yard�m dosyas�n� tamamen okuyun ve nerede hata yapm�� olabilece�inizi ara�t�r�n.

8- Sizin yada kurban�n�z�n PC'si Pr0rAt server� bula�t�ktan k�sa bir s�re sonra yada ProConnective �al��t�rd�ktan sonra kapanmaya ba�l�yorsa bunun sebebi Pr0rAt server� yada ProConnective de�ildir. Son zamanlar da ortaya ��kan msblaster t�revi worm'lar gerekli g�venlik yamas� uygulanmam�� ve dahili firewall� kapal� durumdaki w2k sistemlere s�zarak sistemi s�rekli kapatmaktad�r. Siz yada kurban�n�z bu yamay� uygulayarak PC'sini bu worm'lara kar�� koruma alt�na almad�ysa Pr0rAt server� yada ProConnective �al��t���nda sizin se�iminize ba�l� olarak XP 'dahili firewall�n� kapatacak ve bu sayede bu t�r wormlar'da sisteme eri�im sa�layabilecek ve sistemi s�rekli kapatmaya ba�layacakt�r. Bu yamay� nereden ve nas�l temin edebilece�iniz yard�m dosyas�nda detayl�ca anlat�lmaktad�r.

9- Pr0rAt server�n� d�zenlemeye yada server� Anti vir�slerce tan�nmaz hale getirmeye �al���rsan�z Pr0rAt clienti servera ba�lanmay� ret eder. Anti vir�slere yakalanmayan server sahibi olmak isteyenler Pr0rAt Special Edition sat�n almal�d�r. Detayl� bilgi i�in sale@prohack.net ile irtibata ge�ebilirsiniz. E�er server �zerinde her hangi bir oynama yapmad���n�z halde serverdan bu y�nde bir uyar� al�yorsan�z ve ba�lanam�yorsan�z. Muhtemelen Pr0rAt server�n� kurban�n�za tam olarak y�kleyememi�sinizdir. Baz� trojanlar upload s�ras�nda eksik yada fazla veri yollad�klar� i�in Pr0rAt server�n�n d�zenlendi�ini sanmas�na sebebiyet vermi� olabilir. Yeniden ve ba�ka programlarla server�n�z� y�klemeyi deneyin. Ayr�ca kurban�n�z�n PC'sinde �al��an ve kendisini exe dosyalar�na yazma yetene�ine sahip olan kimi vir�slerde bu hataya neden olabilmektedirler.

10- L�tfen Pr0rAt Clientiniz �zerinde ki Online Haberler b�l�m�ne �nem verin. Zira Pr0rAt ve PRO Grubun di�er t�m �al��malar�yla ilgili haberler size bu sayede aktar�lacakt�r. Online haberler linki bazen sunucu problemleri y�z�nden �al��mayabilir. Ancak bu hi� bir zaman �al��mayaca�� anlam�na gelmemektedir. L�tfen Online Haberleri okuyamaman�z  s�z konusu olursa bir ka� g�n sonra yeniden deneyin.
----------------------------------------------------------------------------------
