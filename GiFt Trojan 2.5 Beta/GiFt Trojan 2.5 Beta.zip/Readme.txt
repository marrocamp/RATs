GiFt 2.5 beta
+++++++++++++

by tr|force
===========


Right here is a little beta release. Only includes the server and client (both compressed). EditServer is still underway, and this is to test the new server functions like messagebox manager etc. Just test it lots to see if the new functions work ok :-) Also try compressing it with different compressors to see which gives the best rate and it still works effectively.


Please report back to:-
eomer@blackcodemail.com

thanks