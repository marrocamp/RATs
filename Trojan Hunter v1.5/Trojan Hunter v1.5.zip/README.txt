=======================================================================
===READ=IT!!=============Trojan/port==Scanners=========================
=======================================================================
         ////////    ////////  ///   ///  //////   //////  ////////
           //       //   //    //  //   //   //  //   //   //     
          //       // //       ////    //       //   //    ///   
          //       ////         //     // ////  //   //     ///  
         //       // //        //     //   //  //   //       //
        //       //  //       //      /////    ////    //////
======================By=====TryGos@WebMonster�====2001==================

TrojanHunter v1.5

1)How it works?

  Simply enter the IP range that you want to scan for the trojans/ports
that you have checked in the right side , press more to set up the logs
and check the pass-crack for netbus under 1.6 , its a very cool scanner
add more ports if you want! :)
    
Good hunt!

=========================================================================
== http://library.2ya.com ============TryGos@WarSites===================
======================By=====TryGos@WebMonster�====2001==================
=========================================================================

my e-mail: nicxxxme@hotmail.com (subject: warsite files)